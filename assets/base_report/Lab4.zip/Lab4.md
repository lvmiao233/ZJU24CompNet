<img src="img/cover.jpg" alt="cover" style="zoom:43%;" />

<div align="left">
  <font face="楷体" size = 5>
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp课程名称：</font><font face="楷体" size = 5><u>&nbsp&nbsp&nbsp计算机网络&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp实验名称：<u>&nbsp&nbsp&nbsp静态路由配置&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp姓&nbsp&nbsp&nbsp&nbsp名：</font><font face="楷体" size = 5><u>&nbsp&nbsp&nbsp{{global-name}}&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp学&nbsp&nbsp&nbsp&nbsp院：</font><font face="楷体" size = 5><u>&nbsp&nbsp&nbsp计算机科学与技术学院&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
     &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp系：</font><font face="楷体" size = 5><u>&nbsp&nbsp&nbsp计算机科学与技术系&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
     &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp专&nbsp&nbsp&nbsp&nbsp业：<u>&nbsp&nbsp&nbsp计算机科学与技术&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp学&nbsp&nbsp&nbsp&nbsp号：<u>&nbsp&nbsp&nbsp{{global-student-id}}&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
     &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp指导教师：<u>&nbsp&nbsp&nbsp陆系群&nbsp&nbsp&nbsp</u>
  </font><br/><br/><br/>
    <center><font face="黑体" size = 5>
    报告日期: {{lab4-date}}
  </font>
    </center>
</div>
<div STYLE="page-break-after: always;"></div>

<center>
    <font face="黑体" size=5>
        <b>浙江大学实验报告</b>
    </font><br/><br/><br/></center>
<div align="left">
    <font face="黑体" size=4>
         &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp课程名称：<u>&nbsp&nbsp&nbsp&nbsp计算机网络&nbsp&nbsp&nbsp</u>实验类型:<u>&nbsp&nbsp&nbsp&nbsp综合&nbsp&nbsp&nbsp</u>
        </font><br/><br/>
    <font face="黑体" size=4>
         &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp实验项目名称:<u>&nbsp&nbsp&nbsp&nbsp Lab4:静态路由配置
 &nbsp&nbsp&nbsp</u>
        </font><br/><br/><font face="黑体" size=4>
         &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp学生姓名:<u>&nbsp{{global-name}}&nbsp</u>专业: <u>&nbsp&nbsp 计算机科学与技术&nbsp&nbsp</u>学号: <u>&nbsp{{global-student-id}}&nbsp</u>
        </font><br/><br/><font face="黑体" size=4>
         &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp同组学生姓名:<u>&nbsp&nbsp&nbsp&nbsp  &nbsp&nbsp&nbsp</u>指导老师: <u>&nbsp&nbsp&nbsp&nbsp陆系群&nbsp&nbsp&nbsp&nbsp</u>
        </font><br/><br/><font face="黑体" size=4>
         &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp实验地点:<u>&nbsp&nbsp&nbsp曹光彪西-304 &nbsp&nbsp&nbsp</u>实验日期: <u>&nbsp&nbsp{{lab4-date}}&nbsp&nbsp</u>
    </font><br/></div>





## 一、实验目的

-   学习掌握路由器的工作原理和配置方法；

-   加深路由和交换功能的区别和联系；

-   理解路由表的原理，掌握子网划分原则；

-   理解静态路由的概念，掌握设置静态路由和默认路由的方法；



## 二、实验内容

-   分别采用静态地址分配、动态地址分配构建多种类型的局域网；

-   使用多个路由器连接多个局域网；

-   分别采用以太网、高速串口等方式连接路由器；

-   通过路由器连接真实网络并实现数据通信；

-   在路由器上配置NAT，实现私有网络和共有网络的互联；

-   在各路由器上配置静态路由，实现网络互联互通。



## 三、主要仪器设备

联网的PC机、路由器、交换机

> [!NOTE]
>
> 本实验可使用模拟器，如使用模拟器完成实验，需独立完成实验全部步骤



## 四、操作方法与实验步骤

-   按拓扑图连接路由器、交换机和PC机；

![](Lab4/image2.png)

-   设计好每个区域内PC和路由器接口的IP地址及掩码，其中：
    -   Zone1区域的IP子网为10.0.0.0/16；
    -   Zone2区域的IP子网为10.1.0.0/16；
    -   Guest区域使用DHCP动态地址分配，IP子网为172.16.0.0/24和172.16.1.0/24；
    -   Private区域需要经过NAT转换后再和其他区域通信，IP子网为192.168.0.0/24；
    -   External区域代表外部实际网络（即R2的f0/0接口连接的是外部真实网络，如校园网），使用GNS3模拟时，是通过Cloud-1这个特殊设备连接外部网络（具体请参考GNS3指南）。


-   为便于记忆，建议路由器之间的接口统一采用192.168.X.Y/24的形式，其中X为两个路由器的编号组合，如12代表R1和R2之间的子网，Y为路由器编号，如192.168.12.1分配给R1的s2/0接口，192.168.12.2分配给R2的s2/0接口。

-   按照上述设计给PC配置合适的IP地址及掩码；

- 按照上述设计给各路由器接口分配合适的IP地址、掩码并激活接口（命令参考下面）：

  ```
  R1(config)# interface 接口名
  R1(config-if)# ip address IP地址 掩码
  R1(config-if)# no shutdown
  ```

-   给PC配置默认路由器地址，测试跨路由器通信；

-   在R4路由器上配置DHCP服务，步骤如下：
    -   配置路由器接口的IP地址；
    -   定义第一个子网的DHCP地址池（命令：`ip dhcp pool 地址池编号`）；
    -   定义DHCP网络地址（命令： `network IP地址 /子网掩码长度`）；
    -   定义DHCP默认网关（命令： `default-router 默认路由器IP地址`）；
    -   根据需要定义第二个子网的DHCP地址池；
    -   启动DHCP服务（命令： `service dhcp`）；
    -   在PC上运行`ip dhcp`，获取IP地址，并查看获得的IP地址。


-   配置R1、R2路由器之间的串口的数据链路层协议为HDLC，并设置IP地址；

-   配置R2、R4路由器之间的串口的数据链路层协议为PPP，并设置IP地址；

-   在各路由器上配置静态路由，使得不相邻路由器之间能够相互通信（命令：`ip route 目标网络 子网掩码 下一跳地址`）；
    
-   在R5路由器上配置NAT服务，使得PC6、PC7以R5的f0/0接口的IP地址对外通信。配置步骤如下：
    -   定义内部接口（命令：`interface fa0/1`, `ip nat inside`)，假设fa0/1是连接内部网络的接口；
    -   定义外部接口（命令：`interface fa0/0`，`ip nat outside`)，假设fa0/0是连接外部网络的接口；
    -   设置访问控制列表（命令：`access-list 1 permit *192.168.0.0 0.0.0.255`*)，允许网络（假设是192.168.0.0/24）向外访问；
    -   定义从内到外的访问需要进行源地址转换，使用路由器的外部接口地址作为转换后的外部地址（命令：`ip nat inside source list 1 interface fa0/0 overload`)。


-   配置R2的f0/0接口，使其能够与外部真实网络上的主机进行通信（请参考《使用GNS3软件模拟IOS指南》中的第十二节“增加网络云”相关内容）；

-   使用Ping命令测试各个区域的PC之间的联通性，根据需要在相应的路由器上补充静态路由设置。



## 五、实验数据记录和处理

> [!NOTE]
>
> 以下实验记录均需结合屏幕截图，进行文字标注和描述，图片应大小合适、关键部分清晰可见，可直接在图片上进行标注，也可以单独用文本进行描述。

1. 设计好每个PC、路由器各接口的IP地址及掩码，并标注在拓扑图上（后续全部按照这个图进行配置）。

   设计的拓扑图:

   {{Lab4-s1-topology}}

   

2. 给PC1配置IP地址为10.0.0.X，给PC2配置IP地址为10.0.1.X，其中X为你的学号后2位或后3位（如果3位都为0，往前取，直到3位不全为0，后同不再说明），均使用24位长度的掩码（即255.255.255.0）。然后用Ping检查PC1、PC2之间的连通性（思考为什么不通）。

   Ping结果截图:

   {{Lab4-s2-ping_result}}

   

3. 将PC1、PC2的掩码长度均改为16位（即255.255.0.0）。然后用Ping检查PC1、PC2之间的连通性。

   Ping结果截图:

   {{Lab4-s3-ping_result}}

   

4. 给R1的两个接口f0/0、f1/0分别配置合适的IP地址，掩码长度均为16，并激活接口。然后查看路由表信息。

   输入的配置命令：

   ```kotlin
   {{Lab4-s4-config_cmd}}
   ```
   
   路由表信息截图:
   
   {{Lab4-s4-routing_table}}
   
   
   
5. 给PC3配置IP地址10.1.0.X，其中X为你的学号后2位或后3位，掩码长度16位（即255.255.0.0）。然后用Ping检查PC1、PC3之间的连通性。

   Ping结果截图:

   {{Lab4-s5-ping_result}}

   

6. 如果上一步Ping的结果是不通，请给PC1、PC3配置合适的路由器地址（Gateway），并再次检查两者之间的连通性。

   配置命令：

   {{Lab4-s6-pc1_config}}

   {{Lab4-s6-pc3_config}}

   Ping结果截图：

   {{Lab4-s6-ping_result}}

   

7. 给R4的f0/0、f0/1两个接口配置IP地址并激活接口。

   配置命令：

   ```kotlin
   {{Lab4-s7-config_cmd}}
   ```
   
   
   
8. 在R4上为第一个接口（f0/0）连接的子网配置DHCP服务。

   配置命令：

   ```kotlin
   {{Lab4-s8-config_cmd}}
   ```
   
   
   
9. 在PC4上使用DHCP动态分配地址，查看获得的IP地址。

   配置命令及获得的IP地址截图：

   {{Lab4-s9-dhcp_result}}

   

10. 在R4上为第二个接口（f0/1）配置DHCP服务。

    配置命令：

   ```kotlin
    {{Lab4-s10-config_cmd}}
   ```



11. 在PC5上使用DHCP动态分配地址，查看获得的IP地址。

    配置命令及获得的IP地址截图：

    {{Lab4-s11-dhcp_result}}

    

12. 用Ping命令测试PC4、PC5之间的连通性。

    Ping结果截图:

    {{Lab4-s12-ping_result}}

    

13. 显示R4上的已分配DHCP主机信息

    {{Lab4-s13-dhcp_info}}

    

14. 配置R1、R2路由器之间的串口，设置数据链路层协议为HDLC（命令：`encapsulation hdlc`），在其中一台路由器上设置时钟速率（命令：`clock rate 速率值`），设置IP地址，激活接口，并测试两个路由器之间的连通性。

    配置命令：

    ```kotlin
    {{Lab4-s14-r1_config}}
    ```

    ```kotlin
    {{Lab4-s14-r2_config}}
    ```

    Ping结果截图:

    {{Lab4-s14-ping_result}}

    

15. 配置R4、R2路由器之间的串口，设置IP地址，设置数据链路层协议为PPP（命令：`encapsulation ppp`），设置PPP认证模式为CHAP（命令：`ppp authentication chap`），为对方设置认证用户名和密码（命令：`username R4 password 1234`），用户名默认就是对方的路由器hostname（区分大小写），密码要设置成一样的。激活接口，查看串口状态并测试两个路由器之间的连通性。

    配置命令：

    ```kotlin
    {{Lab4-s15-r2_config}}
    ```

    ```kotlin
    {{Lab4-s15-r4_config}}
    ```

    查看串口状态（LCP Open表明PPP的LCP已经协商完成，身份验证通过）：

    {{Lab4-s15-serial_status}}

    Ping结果截图：

    {{Lab4-s15-ping_result}}

    

16. 配置R1、R3路由器之间接口的IP地址，激活接口，并测试两个路由器之间的连通性。

    配置命令：

    ```kotlin
    {{Lab4-s16-r1_config}}
    ```

    ```kotlin
    {{Lab4-s16-r3_config}}
    ```

    Ping结果截图：

    {{Lab4-s16-ping_result}}

    

17. 配置R4、R3路由器之间接口的IP地址，激活接口，并测试两个路由器之间的连通性。

    配置命令：

    ```kotlin
    {{Lab4-s17-r3_config}}
    ```

    ```kotlin
    {{Lab4-s17-r4_config}}
    ```

    Ping结果截图：

    {{Lab4-s17-ping_result}}

    

18. 分别测试PC1与PC4、PC1与PC5、PC3与PC4、PC3与PC5之间的连通性。

    Ping结果截图:

    * PC1→PC4

      {{Lab4-s18-pc1_to_pc4}}

    * PC1→PC5

      {{Lab4-s18-pc1_to_pc5}}

    * PC3→PC4

      {{Lab4-s18-pc3_to_pc4}}

    * PC3→PC5

      {{Lab4-s18-pc3_to_pc5}}

      

19. 查看各路由器的路由表信息（命令：`show ip route`），分析上述不能Ping通的原因是缺少了哪些路由信息，为下一步添加路由做准备。

    路由表信息截图:

    * R1

      {{Lab4-s19-r1_routing}}

    * R2

      {{Lab4-s19-r2_routing}}

    * R3

      {{Lab4-s19-r3_routing}}

    * R4

      {{Lab4-s19-r4_routing}}

      

20. 在各个路由器上为相应的目标网络（Zone1, Zone2, Guest zone所在子网）添加静态路由（优先选择以太网线路作为下一跳路径），以便上述三个区内的PC能够互相Ping通（不通请仔细分析是哪一台路由器缺少了路由）。记录最后的路由表信息。

    配置命令（请保留路由器提示符）：

    * R1:

      ```kotlin
      {{Lab4-s20-r1_config}}
      ```
      
    * R2:
    
      ```kotlin
      {{Lab4-s20-r2_config}}
      ```
    
    * R3:
    
      ```kotlin
      {{Lab4-s20-r3_config}}
      ```
    
    * R4:
    
      ```kotlin
      {{Lab4-s20-r4_config}}
      ```
    
    Ping结果截图:
    
    * PC1与PC4：
    
      {{Lab4-s20-pc1_to_pc4}}
    
    * PC1与PC5：
    
      {{Lab4-s20-pc1_to_pc5}}
    
    * PC3与PC4：
    
      {{Lab4-s20-pc3_to_pc4}}
    
    * PC3与PC5：
    
      {{Lab4-s20-pc3_to_pc5}}
    
    路由表信息截图:
    
    * R1:
    
      {{Lab4-s20-r1_routing}}
    
    * R2:
    
      {{Lab4-s20-r2_routing}}
    
    * R3:
    
      {{Lab4-s20-r3_routing}}
    
    * R4:
    
      {{Lab4-s20-r4_routing}}
      
      
    
21. 在R1和R4上增加备用路由，选择串口线路作为下一跳的路径，并将路由距离设置成30（命令：`ip
    route 目标网络 子网掩码 下一跳地址 距离`）。此时查看路由表，该新增路由信息并不会出现，但在主路由链路断开时（在R1、R4上关闭与R3连接的端口），该路由会被自动添加进路由表。通过实验验证一下。
    
    配置命令：
    
    * R1：
    
      ```kotlin
      {{Lab4-s21-r1_config}}
      ```
      
    * R4：
    
      ```kotlin
      {{Lab4-s21-r4_config}}
      ```
    
    
    A) R1-R3、R4-R3间链路断开前：
    
    * R1路由表信息截图
    
      {{Lab4-s21-r1_routing_a}}
    
    * R4路由表信息截图
    
      {{Lab4-s21-r4_routing_a}}
    
    * PC1上的路由跟踪截图（命令：`trace 目标网络`):
    
      {{Lab4-s21-trace_result_a}}
    
    B) R1-R3、R4-R3间链路断开后：
    
    * R1路由表信息截图:
    
      {{Lab4-s21-r1_routing_b}}
    
    * R4路由表信息截图:
    
      {{Lab4-s21-r4_routing_b}}
    
    * PC1上的路由跟踪截图:
    
      > [!NOTE]
      >
      > 如果不通，请检查R2上是否添加了相应的路由
    
      {{Lab4-s21-trace_result_b}}
    
    C) R1-R3、R4-R3间链路重新打开后：
    
    * R1路由表信息截图:
    
      {{Lab4-s21-r1_routing_c}}
    
    * R4路由表信息截图:
    
      {{Lab4-s21-r4_routing_c}}
      
      
    
22. 在R1上分别使用f1/0、s2/0接口的IP地址作为源地址，测试到R4的s2/1接口地址的连通性（命令：`ping
    目标IP地址 source 源IP地址`），如果有哪个不通，在各个路由器上增加相应的静态路由信息。
    
    Ping结果截图（Ping通后再截图）:
    
    * R1的f0/0与R4的s2/1：
    
      {{Lab4-s22-f0_0_ping}}
    
    * R1的f0/1与R4的s2/1：
    
      {{Lab4-s22-f0_1_ping}}
    
    * R1的f1/0与R4的s2/1：
    
      {{Lab4-s22-f1_0_ping}}
    
    * R1的s2/0与R4的s2/1：
    
      {{Lab4-s22-s2_0_ping}}
    
    补充静态路由的配置命令：
    
    * R1：
    
      ```kotlin
      {{Lab4-s22-r1_config}}
      ```
    
    * R2：
    
      ```kotlin
      {{Lab4-s22-r2_config}}
      ```
    
    * R3：
    
      ```kotlin
      {{Lab4-s22-r3_config}}
      ```
    
    * R4：
    
      ```kotlin
      {{Lab4-s22-r4_config}}
      ```
    
      

23. 给R3的f0/0（R3-R5之间）接口配置IP地址，给R5各接口配置IP地址，激活接口，并测试两个路由器之间的连通性。

    配置命令：

    * R3：

      ```kotlin
      {{Lab4-s23-r3_config}}
      ```

    * R5：

      ```kotlin
      {{Lab4-s23-r5_config}}
      ```

	Ping结果截图:

	{{Lab4-s23-ping_result}}



24. 给PC6、PC7配置IP地址及默认路由器地址（选R5作为默认路由器），其中PC6地址的主机部分为你的学号后2位或后3位（规则同前）。

    配置命令：

    ```kotlin
    {{Lab4-s24-pc6_config}}
    ```

    ```kotlin
    {{Lab4-s24-pc7_config}}
    ```

    

25. 在R5路由器上配置NAT服务，定义fa0/1接口为内部接口，定义fa0/0接口为外部接口。配置完成后同时在PC6、PC7上持续Ping路由器R3的fa0/0接口地址（命令：`ping ip地址 -t`），Ping通后在R5上显示NAT信息（命令：`show ip nat translation`），可以看出内部的源IP地址被转换成了外部IP地址。

    配置命令：

    ```kotlin
    {{Lab4-s25-nat_config}}
    ```
    
    NAT信息截图：
    
    {{Lab4-s25-nat_info}}



26. 在各路由器上增加静态路由信息，使得PC6能够与Zone1、Zone2、Guest Zone的PC机通信。

	>  [!NOTE]
	>
	> 在R5上可以通过设置默认路由方式简化路由配置（命令：`ip route 0.0.0.0 0.0.0.0 默认路由器IP地址`），而Private Zone对其他区域是不可见的，所以在外部路由器上是不需要为其添加路由的（只需要添加R3-R5之间的子网）。
	
	配置命令：
	
	* R1:
	
	  ```kotlin
	  {{Lab4-s26-r1_config}}
	  ```
	
	* R2:
	
	  ```kotlin
	  {{Lab4-s26-r2_config}}
	  ```
	
	* R3:
	
	  ```kotlin
	  {{Lab4-s26-r3_config}}
	  ```
	
	* R4:
	
	  ```kotlin
	  {{Lab4-s26-r4_config}}
	  ```
	
	* R5:
	
	  ```kotlin
	  {{Lab4-s26-r5_config}}
	  ```
	
	Ping结果截图:
	
	* PC6与PC1：
	
	  {{Lab4-s26-pc6_to_pc1}}
	
	* PC6与PC3：
	
	  {{Lab4-s26-pc6_to_pc3}}
	
	* PC6与PC4：
	
	  {{Lab4-s26-pc6_to_pc4}}
	
	* PC6与PC5：
	
	  {{Lab4-s26-pc6_to_pc5}}




27. 默认情况下，Cloud-1的eth0接口工作在仅主机模式，IP地址是动态分配的，与电脑主机的某个虚拟网卡处于同一个子网。因此配置R2的f0/0接口IP地址时也采用动态分配方式（命令：`ip addess dhcp`）。配置完成后查看R2获得的IP地址，然后在电脑主机上打开命令行，Ping一下R2的IP地址。

    配置命令：

    ```kotlin
    {{Lab4-s27-config_cmd}}
    ```

    R2获得的IP地址截图：

    {{Lab4-s27-r2_ip}}

    电脑主机与R2之间 Ping结果截图：

    {{Lab4-s27-host_ping}}

    

28. 在R2上配置NAT服务，并且在R1上添加电脑主机的子网路由，使得Zone 1的PC机也能与电脑主机通信。提示：定义f0/0接口为外部接口，s2/0为内部接口。

    R2配置命令：

    ```kotlin
    {{Lab4-s28-r2_config}}
    ```

    R1配置命令：

    ```kotlin
    {{Lab4-s28-r1_config}}
    ```

    电脑主机的IP地址:

    {{Lab4-s28-host_ip}}

    PC1与电脑主机Ping结果截图（请关闭电脑上的防火墙）:

    {{Lab4-s28-ping_result}}

    

29. 找一个不需要认证、没有地址绑定限制的网络环境（首选实验室、机房，或者自己搭一个环境），首先配置电脑主机的IP地址和默认网关，以便让电脑主机能够正常连接真实网络，再找一台该网络可以Ping通的主机H。

    接下来让R2的f0/0口改为连接Cloud-1的eth2接口（该接口采用桥接模式，如果没有eth2，请参照GNS指南添加一个），使用静态或动态方式给R2的f0/0口配置IP地址（采用动态分配时需要再次输入`ip address dhcp`，以便路由器重新获取IP地址），设置R2的默认路由地址为真实网络上的默认网关，在R1上为主机H的子网配置路由（可以简化配置成默认路由），测试R2以及PC1能否Ping通该主机。

    R2配置命令：

    ```kotlin
    {{Lab4-s29-r2_config}}
    ```

    R1配置命令：

    ```kotlin
    {{Lab4-s29-r1_config}}
    ```

    R2与真实网络主机H的Ping结果截图:

    {{Lab4-s29-r2_ping}}

    PC1与真实网络主机H的Ping结果截图:

    {{Lab4-s29-pc1_ping}}

    

30. 整理各路由器的当前运行配置，选择与本实验相关的内容记录在文本文件中，每个设备一个文件，分别命名为R1.txt、R2.txt等，随实验报告一起打包上传。



## 六、实验结果与分析

根据你观察到的实验数据和对实验原理的理解，分别解答以下问题：

* 路由器的接口为什么会出现：FastEthernet0/1 is up, line protocol is down的状态？

  {{Lab4-q1}}

* 路由起什么作用？什么是静态路由？

  {{Lab4-q2}}

* 需要为每个PC的IP地址添加路由，还是只需要为其网络地址添加路由？

  {{Lab4-q3}}

* 添加静态路由时，下一跳地址是填写本路由器的端口地址，还是对方路由器的端口地址？或者是目的地网络的路由器端口地址？

  {{Lab4-q4}}

* 什么是默认路由？添加默认路由的命令格式是什么？

  {{Lab4-q5}}

* 在同一个局域网内的2台PC机，IP地址分别为10.0.0.x/24和10.0.1.x/24，都属于VLAN1，一开始不能互相Ping通，为什么把子网掩码长度从24位变成16位，就通了？

  {{Lab4-q6}}

* 如果仅仅是为了让不同区域内的PC之间能够互相Ping通，在设置静态路由时，路由器之间互联的子网是否全部都要加入到所有路由器的路由表中？为什么？

  {{Lab4-q7}}

 

## 七、讨论、心得

在完成本实验后，你可能会有很多待解答的问题，你可以把它们记在这里，接下来的学习中，你也许会逐渐得到答案的，同时也可以让老师了解到你有哪些困惑，老师在课堂可以安排针对性地解惑。等到课程结束后，你再回头看看这些问题时你或许会有不同的见解：

 {{lab4-question}}

在实验过程中你可能会遇到的困难，并得到了宝贵的经验教训，请把它们记录下来，提供给其他人参考吧：

 {{lab4-experience}}

你对本实验安排有哪些更好的建议呢？欢迎献计献策：

 {{lab4-suggestion}}
