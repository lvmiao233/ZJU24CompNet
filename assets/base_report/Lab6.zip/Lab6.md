<img src="img/cover.jpg" alt="cover" style="zoom:43%;" />

<div align="left">
  <font face="楷体" size = 5>
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp课程名称：</font><font face="楷体" size = 5><u>&nbsp&nbsp&nbsp计算机网络&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp实验名称：<u>&nbsp&nbsp&nbsp动态路由协议BGP配置&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp姓&nbsp&nbsp&nbsp&nbsp名：</font><font face="楷体" size = 5><u>&nbsp&nbsp&nbsp 姓名&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp学&nbsp&nbsp&nbsp&nbsp院：</font><font face="楷体" size = 5><u>&nbsp&nbsp&nbsp计算机科学与技术学院&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
     &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp系：</font><font face="楷体" size = 5><u>&nbsp&nbsp&nbsp计算机科学与技术系&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
     &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp专&nbsp&nbsp&nbsp&nbsp业：<u>&nbsp&nbsp&nbsp计算机科学与技术&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp学&nbsp&nbsp&nbsp&nbsp号：<u>&nbsp&nbsp&nbsp学号&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
     &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp指导教师：<u>&nbsp&nbsp&nbsp陆系群&nbsp&nbsp&nbsp</u>
  </font><br/><br/><br/>
    <center><font face="黑体" size = 5>
    报告日期: 2026年月日
  </font>
    </center>
</div>
<div STYLE="page-break-after: always;"></div>

<center>
    <font face="黑体" size=5>
        <b>浙江大学实验报告</b>
    </font><br/><br/><br/></center>
<div align="left"> 
    <font face="黑体" size=4>
         &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp课程名称：<u>&nbsp&nbsp&nbsp&nbsp计算机网络&nbsp&nbsp&nbsp</u>实验类型:<u>&nbsp&nbsp&nbsp&nbsp综合&nbsp&nbsp&nbsp</u>
        </font><br/><br/>
    <font face="黑体" size=4>
         &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp实验项目名称:<u>&nbsp&nbsp&nbsp&nbsp Lab6:动态路由协议BGP配置
 &nbsp&nbsp&nbsp</u>
        </font><br/><br/><font face="黑体" size=4>
         &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp学生姓名:<u>&nbsp&nbsp  &nbsp</u>专业: <u>&nbsp&nbsp 计算机科学与技术&nbsp&nbsp</u>学号: <u>&nbsp&nbsp &nbsp&nbsp</u>
        </font><br/><br/><font face="黑体" size=4>
         &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp同组学生姓名:<u>&nbsp&nbsp&nbsp&nbsp  &nbsp&nbsp&nbsp</u>指导老师: <u>&nbsp&nbsp&nbsp&nbsp陆系群&nbsp&nbsp&nbsp&nbsp</u>
        </font><br/><br/><font face="黑体" size=4>
         &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp实验地点:<u>&nbsp&nbsp&nbsp曹光彪西-304 &nbsp&nbsp&nbsp</u>实验日期: <u>&nbsp&nbsp 2026年月日&nbsp&nbsp</u>
    </font><br/></div>





## 一、实验目的

1.  理解距离向量路由协议的工作原理。

2.  理解BGP协议的工作机制。

3.  掌握配置和调试BGP协议的方法。



## 二、实验内容

-   创建多种类型的网络，各自成为一个独立的AS

-   AS内部路由器配置成启用OSPF路由协议

-   在同一个AS边界上的路由器启用BGP协议，形成邻居关系

-   在不同AS边界路由器上启用BGP协议，直连路由器之间建立邻居关系

-   观察各路由器上的路由表和BGP运行数据，并验证各PC能够相互Ping通

-   断开某些链路，观察BGP事件和路由表变化

-   在AS边界路由器上配置路由聚合

-   在AS间进行多径负载均衡



## 三、主要仪器设备

PC机、路由器、Console连接线、直联网络线、交叉网络线

如果物理设备不足，可以使用模拟软件，建议使用GNS3软件,详情请参考《使用GNS3软件模拟IOS指南》。



## 四、操作方法与实验步骤

按照下面的拓扑图连接路由器和PC机。每个自治系统（AS）均分配1个独立的AS号。其中，AS 65003内部运行OSPF路由协议，R6、R7、R8分别代表一个AS。

{{Lab6-p0-s1-topology}}

#### 实验主要步骤：

* 配置路由器各接口的IP地址（除了R1的f0/1、R2的f0/0接口配置IPv6的地址外，其他均配置IPv4的地址）, 使直连的2个路由器能相互Ping通，为方便记忆，建议使用192.168.xy.x/24、192.168.xy.y/24形式的地址，其中x,y分别是相连路由器的编号, 例如可以设置R1连接R3的f1/0接口IP为192.168.13.1，R3连接R1的f1/0接口IP为192.168.13.3，其他类推；
* 在各AS边界路由器之间建立邻居关系；
* 在AS 65003内部的两头边界路由器（R3、R5）之间建立邻居关系；
* 在AS 65003内部启用OSPF路由协议，并启用重分发机制，让OSPF和BGP之间信息互通；
* 在R8上配置路由过滤，使得到达PC3子网的路由不经过AS 65008；
* 给PC1、PC3配置IPv4地址，使用10.0.x.y/24的形式的私网地址，其中x为子网号，y为主机地址；
* 给R1、R2、R6的f0/1接口、R1、R6的f2/0接口以及PC2、PC4、PC5配置IPv6的地址，使用FEC0:\:x:y:z/112形式的站点本地地址，其中x、y为子网号，z为主机地址；
* IPv6的地址分配规则：
  * FEC0::/10前缀的地址是IPv6站点本地地址段（site-local），相当于IPv4的私网地址段；
  * FE80::/10前缀的地址是用于IPv6链路本地的地址段（link-local）。给接口配置site-local地址时会自动分配link-local地址，也可以手工配置link-local地址。由于同一个接口可以配置多个IPv6地址，为避免路由学习时产生多个Next-hop，路由器只把link-local地址作为Next-hop。路由器会自动通告link-local地址的前缀，PC可以根据这些信息自动配置link-local地址，并发现路由。

* 在R1和R2之间建立隧道，使得配置了IPv6的主机之间能通过中间的IPv4网络相互通信。

 

#### BGP知识点：

* 64512-65534之间的AS号属于私有AS号，不在互联网出现。
* 两个路由器都在同一个AS，称为iBGP邻居，链路称为内部link。iBGP邻居之间的链路可以为非直连链路，数据需要通过其他路由器转发。
* 两个路由器分属于不同的AS，称为eBGP邻居，链路称为外部link。
* BGP路由状态：*表示有效路由，>表示最佳路由，i表示内部路由，r表示写入路由表时被拒绝，原因可能是路由表中已存在优先级更高的同样路由。比如OSPF属于内部网关路由协议，优先级比外部网关路由协议BGP高。
* 多个AS之间互相连接，从R1到R2存在多条AS间的路径，例如：
  * 65001->65003->65002
  * 65001->65006->65007-65009->65002
  * 65001->65006->65008->65009->65002

* BGP选择最佳路由的依据有很多，默认是选择经过最少AS数量的路径，不以接口速度带宽为标准。

* 路由器在发送BGP消息时，可能使用物理接口的IP地址作为源地址，这样会因为与对方配置的邻居地址不符，导致无法建立邻居关系。因此需要设置更新源为回环接口，可以避免这种情况发生。

* 同步功能是让BGP等待内部路由器(如R4)学到了外部路由后才对外发布。重分发功能是把其他路由协议（如BGP）学习到的路由添加到自己数据库中(如OSPF)。

* 路由聚合是将路由表中下一跳相同的多个网络合并成一个网络，这样可以减少路由表的大小，加速路由器转发处理速度。

 

#### BGP相关命令：

* 在路由器R1上启用BGP协议, 设置AS号，并宣告直连网络：

  ```kotlin
  R1(config)# router bgp <AS-Number>
  R1(config-router)# network x.x.x.x mask x.x.x.x
  ```

* 把对方增加为AS内部的邻居（AS-Number设置为相同的AS号）

  ```kotlin
  R1(config-router)# neighbor <IP-Address> remote-as <AS-Number>
  ```

* 对方增加为AS间的邻居（IP-Address为对方的IP，AS-Number设置为对方的AS号）：

  ```kotlin
  R1(config-router)# neighbor <IP-Address> remote-as <AS-Number>
  ```

* 查看邻居关系：

  ```kotlin
  R1# show ip bgp neighbor
  ```

* 打开bgp调试：

  ```kotlin
  R1# debug ip bgp
  ```

* 查看BGP数据库：

  ```kotlin
  R1# show ip bgp
  ```

* 启用BGP同步功能：

  ```kotlin
  R1(config-router)# synchronization
  ```

* 设置BGP更新源为回环接口（IP-Addr设置为对方的回环口IP）：

  ```kotlin
  R1(config-router)# neighbor <IP-Addr> update-source loopback 0
  ```

* 在BGP中启用路由重分发功能，从OSPF中重分发路由信息：

  ```kotlin
  R1(config)# router bgp <AS-Number>
  R1(config-router)# redistribute ospf <process-id>
  ```

* 在OSPF中启用重分发功能，从BGP中重分发路由信息：

  ```kotlin
  R1(config)# router ospf <process-id> 
  R1(config-router)# redistribute bgp <AS-Number> subnets
  ```

* 聚合路由（summary-only参数的含义是只传递聚合后的路由，as-set参数的含义是在传播网络时加上AS属性，避免出现循环路由）：

  ```kotlin
  R1(config-route)# aggregate-address <ip network> <subnet mask> summary-only as-set
  ```

* 设置允许多条路径：

  ```kotlin
  R1(config-route)# maximum-paths 2
  ```

 

## 五、实验数据记录和处理

>  [!NOTE]
>
> 以下实验记录均需结合屏幕截图，进行文字标注和描述，图片应大小合适、关键部分清晰可见，可直接在图片上进行标注，也可以单独用文本进行描述。

1. 参考实验操作方法的说明，设计好每个PC、路由器各接口的IP地址及掩码（除了PC2、PC4、PC5以及与之相连的路由器接口配置IPv6的地址外，其他均配置IPv4的地址），并标注在拓扑图上。

   设计的拓扑图：

   {{Lab6-p0-s1-topology}}
   
   

### Part 1. 配置iBGP

2. 分别在R3、R4、R5上配置回环端口、各物理接口的IP地址，激活OSPF动态路由协议，宣告直连网络。其中进程ID请设置为学号的后2位（全0者往前取值）。

   R3配置命令：

   ```kotlin
   {{Lab6-p1-s2-r3_config}}
   ```
   
   R4配置命令：
   
   ```kotlin
   {{Lab6-p1-s2-r4_config}}
   ```
   
   R5配置命令：
   
   ```kotlin
   {{Lab6-p1-s2-r5_config}}
   ```
   
   
   
3. 查看R3、R4、R5的路由表，并在R3上用Ping测试与R5的回环口（用回环口作为源地址，命令：`ping [IP-addr] source loopback 0`）之间的联通性。

   R3路由表：

   {{Lab6-p1-s3-r3_route}}

   R4路由表：

   {{Lab6-p1-s3-r4_route}}

   R5路由表：

   {{Lab6-p1-s3-r5_route}}

   R3R5的Ping结果：

   {{Lab6-p1-s3-ping_result}}

   

4. 启动R3、R5上的BGP协议（配置成同一个AS），宣告直连网络，然后把对方增加为AS内部的邻居（命令：`neighbor [IP-Address] remote-as [AS-Number]`），IP-Address为对方回环接口的IP，AS-Number设置为相同的AS号。

   R3配置命令：

   ```kotlin
   {{Lab6-p1-s4-r3_bgp_config}}
   ```

   R5配置命令：

   ```kotlin
   {{Lab6-p1-s4-r5_bgp_config}}
   ```

   

5. 分别在R3、R5上查看BGP邻居关系（命令：`show ip bgp neighbor`），标出Link类型和对方的IP、连接状态。如果没有活动的TCP连接，打开调试开关（命令：`debug ip bgp`），查看错误原因。观察完毕关掉调试（命令：`no debug ip bgp`）。

   R3的邻居关系：观察得知，邻居的IP是` {{Lab6-p1-s5-r3-ip}} `，链路类型属于`{{Lab6-p1-s5-r3-type}}`，状态是`{{Lab6-p1-s5-r3-state}}`，但现象是没有活动的TCP连接。

   {{Lab6-p1-s5-r3_neighbor}}

   R5的邻居关系：观察得知，邻居的IP是`{{Lab6-p1-s5-r5-ip}}`，链路类型属于`{{Lab6-p1-s5-r5-type}}`，状态是`{{Lab6-p1-s5-r5-state}}`，但现象是没有活动的TCP连接。

   {{Lab6-p1-s5-r5_neighbor}}

   打开debug后的消息：错误原因是被对方拒绝连接，是因为R3默认使用了物理接口的IP地址作为源地址，而R5配置的邻居地址是R3的`{{Lab6-p1-s5-interface}}`，因邻居地址不符被拒绝。

   {{Lab6-p1-s5-debug_msg}}

   

6. 在R3、R5上设置BGP更新源为回环接口（命令：`neighbor [IP-Addr] update-source loopback 0`），等待一会儿，再次查看邻居关系，标记连接状态是否已建立（ESTAB）。

   R3配置命令：

   ```kotlin
   {{Lab6-p1-s6-r3_update_source}}
   ```

   R5配置命令：

   ```kotlin
   {{Lab6-p1-s6-r5_update_source}}
   ```

   R3的邻居关系（选取关键信息进行截图）：观察得知，与R5的邻居关系已经建立，对方的连接端口是`{{Lab6-p1-s6-r3-port}}`。

   {{Lab6-p1-s6-r3_neighbor}}

   R5的邻居关系（选取关键信息进行截图）：观察得知，与R3的邻居关系已经建立，对方的连接端口是`{{Lab6-p1-s6-r5-port}}`。

   {{Lab6-p1-s6-r5_neighbor_established}}

   

7. 在R3、R5上查看BGP数据库（命令：show ip bgp），并查看路由表信息。

   R3的BGP数据库（标出iBGP路由）：观察得知，存在`{{Lab6-p1-s7-r3-count}}`条状态码=r的路由（表示没有成功写入路由表）。

   {{Lab6-p1-s7-r3_bgp_db}}

   R3的路由表：观察得知，网络地址`{{Lab6-p1-s7-r3-net1}}`、`{{Lab6-p1-s7-r3-net2}}`在路由表中已存在比BGP优先级高的OSPF路由，所以BGP的路由信息没有成功写入。

   {{Lab6-p1-s7-r3_route_table}}

   R5的BGP数据库（标出iBGP路由）：

   {{Lab6-p1-s7-r5_bgp_db}}

   R5的路由表（标出在BGP数据库中存在，但优先级更高的OSPF路由）：

   {{Lab6-p1-s7-r5_route_table}}
   
   

### Part 2. 配置eBGP

8. 在R1、R2、R6、R7、R8上激活路由器互联的接口，配置IP地址，启用BGP协议，每个路由器使用不同的AS号，宣告所有直连网络，把直接连接的对方增加为AS间的邻居（命令：`neighbor [IP-Address] remote-as [AS-Number]`），IP-Address为对方的IP，AS-Number设置为对方的AS号。

   R1的配置命令：

   ```kotlin
   {{Lab6-p2-s8-r1_config}}
   ```
   
   R2的配置命令：
   
   ```kotlin
   {{Lab6-p2-s8-r2_config}}
   ```
   
   R6的配置命令：
   
   ```kotlin
   {{Lab6-p2-s8-r6_config}}
   ```

   R7的配置命令：

   ```kotlin
   {{Lab6-p2-s8-r7_config}}
   ```
   
   R8的配置命令：
   
   ```kotlin
   {{Lab6-p2-s8-r8_config}}
   ```
   
   
   
9. 在R3、R5上分配配置R1、R2为外部BGP邻居。

   R3的配置命令：

   ```kotlin
   {{Lab6-p2-s9-r3_ebgp_config}}
   ```
   

    R5的配置命令：

    ```kotlin
    {{Lab6-p2-s9-r5_ebgp_config}}
    ```

   

10. 在各路由器上查看邻居关系，标出Link类型和对方的IP、连接状态（找出关键信息进行截图）。

    R1的邻居关系：R1的两个邻居的IP分别为`{{Lab6-p2-s10-r1-ip1}}`、`{{Lab6-p2-s10-r1-ip2}}`，链路类型均为`{{Lab6-p2-s10-r1-type}}`。

    {{Lab6-p2-s10-r1_neighbor1}}

    {{Lab6-p2-s10-r1_neighbor2}}

    R2的邻居关系：R2邻居的IP分别为`{{Lab6-p2-s10-r2-ip1}}`、`{{Lab6-p2-s10-r2-ip2}}`，链路类型均为`{{Lab6-p2-s10-r2-type}}`。

    {{Lab6-p2-s10-r2_neighbor1}}

    {{Lab6-p2-s10-r2_neighbor2}}

    R3的邻居关系：R3的iGP邻居的IP为`{{Lab6-p2-s10-r3-igp}}`，eBGP邻居的IP为`{{Lab6-p2-s10-r3-ebgp}}`。

    {{Lab6-p2-s10-r3_neighbor1}}

    {{Lab6-p2-s10-r3_neighbor2}}

    R5的邻居关系：R3的iGP邻居的IP为为`{{Lab6-p2-s10-r5-igp}}`，eBGP邻居的IP为为`{{Lab6-p2-s10-r5-ebgp}}`。

    {{Lab6-p2-s10-r5_neighbor1}}

    {{Lab6-p2-s10-r5_neighbor2}}

    R6的邻居关系：R6的两个邻居的IP分别为`{{Lab6-p2-s10-r6-ip1}}`、`{{Lab6-p2-s10-r6-ip2}}`，链路类型均为`{{Lab6-p2-s10-r6-type}}`。

    {{Lab6-p2-s10-r6_neighbor1}}

    {{Lab6-p2-s10-r6_neighbor2}}

    R7的邻居关系：R7的两个邻居的IP分别为`{{Lab6-p2-s10-r7-ip1}}`、`{{Lab6-p2-s10-r7-ip2}}`，链路类型均为`{{Lab6-p2-s10-r7-type}}`。

    {{Lab6-p2-s10-r7_neighbor1}}

    {{Lab6-p2-s10-r7_neighbor2}}

    R8的邻居关系：R8的两个邻居的IP分别为`{{Lab6-p2-s10-r8-ip1}}`、`{{Lab6-p2-s10-r8-ip2}}`，链路类型均为`{{Lab6-p2-s10-r8-type}}`。

    {{Lab6-p2-s10-r8_neighbor1}}

    {{Lab6-p2-s10-r8_neighbor2}}

    

11. 等待一会儿，在路由器R1查看BGP数据库，标出到达R2-R5间子网、R6-R7间子网、R7-R8间子网以及R2-R8间子网的最佳路由（标记为\> 的为最佳路由）、经过的AS路径。
    
    R1的BGP数据库：
    
    {{Lab6-p2-s11-r1_bgp_db}}
    
    观察得知：
    
    * 到达R2-R5间子网的下一跳是`{{Lab6-p2-s11-r25-nh}}`，经过的AS路径为`{{Lab6-p2-s11-r25-path}}`；
    * 到达R6-R7间子网的下一跳是`{{Lab6-p2-s11-r67-nh}}`，经过的AS路径为`{{Lab6-p2-s11-r67-path}}`；
    * 到达R7-R8间子网的路由有`{{Lab6-p2-s11-r78-count}}`条，其中最佳路由的下一跳是`{{Lab6-p2-s11-r78-nh}}`，经过的AS路径最短，AS号依次为`{{Lab6-p2-s11-r78-path}}`；
    * 到达R8-R2间子网的路由有`{{Lab6-p2-s11-r82-count}}`条，其中最佳路由的下一跳是`{{Lab6-p2-s11-r82-nh}}`，经过的AS路径最短，AS号依次为`{{Lab6-p2-s11-r82-path}}`。
    
    
    
12. 在路由器R2查看BGP数据库，标出到达R1-R3间子网、R1-R6间子网、R6-R7间子网以及R7-R8间子网的最佳路由、经过的AS路径。

    R2的BGP数据库：

    {{Lab6-p2-s12-r2_bgp_db}}

    观察得知：

    * 到达R1-R3间子网的下一跳是`{{Lab6-p2-s12-r13-nh}}`，经过的AS路径为`{{Lab6-p2-s12-r13-path}}`；
    * 到达R7-R8间子网的下一跳是`{{Lab6-p2-s12-r78-nh}}`，经过的AS路径为`{{Lab6-p2-s12-r78-path}}` ；
    * 到达R1-R6间子网的路由有`{{Lab6-p2-s12-r16-count}}`条，其中最佳路由的下一跳是`{{Lab6-p2-s12-r16-nh}}`，经过的AS路径最短，AS号依次为`{{Lab6-p2-s12-r16-path}}`；
    * 到达R6-R7间子网的路由有`{{Lab6-p2-s12-r67-count}}`条，其中最佳路由的下一跳是`{{Lab6-p2-s12-r67-nh}}`，经过的AS路径最短，AS号依次为`{{Lab6-p2-s12-r67-path}}` 。

    

13. 在路由器R1上查看路由表，标出到达R2-R5间子网、R6-R7间子网、R7-R8间子网以及R2-R8间子网的路由，是否与BGP数据库中的最佳路由一致。

    R1的路由表：

    {{Lab6-p2-s13-r1_route_table}}

    

14. 在路由器R2上查看路由表，标出到达R1-R3间子网、R1-R6间子网、R6-R7间子网以及R7-R8间子网的路由，是否与BGP数据库中的最佳路由一致。

    R2的路由表：

    {{Lab6-p2-s14-r2_route_table}}

    

15. 在路由器R6查看BGP数据库，标出到达R2-R5间子网的最佳路由、经过的AS路径。然后在R1上关闭R1-R3互联端口后（命令：`interface f1/0`, `shutdown`），在R6上观察到达R2-R5间子网的最佳路由有无变化。

    R6的BGP数据库（当前）：到达R2-R5间子网的最佳路由的下一跳为`{{Lab6-p2-s15-before}}`。

    {{Lab6-p2-s15-r6_bgp_before}}

    R6的BGP数据库（断开连接后）：观察得知，到达R2-R5间子网的最佳路由的下一跳变为`{{Lab6-p2-s15-after}}`。

    {{Lab6-p2-s15-r6_bgp_after}}
    
    

### Part 3. 路由重分发

16. 重新激活R1-R3之间的端口（命令：`no shutdown`），等待R1重新选择R3作为到达R2-R8间子网的最佳BGP路由。然后测试R1是否能Ping通R2-R8互联端口，并跟踪R1到该子网的路由（命令：`traceroute ip-addr`，如果提前终止，可按Ctrl+6）。

    Ping结果：

    {{Lab6-p3-s16-ping_result}}

    路由跟踪结果：得到的现象是在路由器`{{Lab6-p3-s16-router}}`中断了。

    {{Lab6-p3-s16-traceroute_result}}

    

17. 查看R3的BGP数据库和路由表，标记到达R2-R8间子网的BGP最佳路由。查看R4的路由表是否存在R2-R8间子网的路由信息。

    R3的BGP数据库：观察得知，到达R2-R8间子网的最佳路由的下一跳IP地址是`{{Lab6-p3-s17-r3-nh}}`。

    {{Lab6-p3-s17-r3_bgp_db}}

    R3的路由表：观察得知，

    * 到达R2-R8间子网的下一跳IP地址`{{Lab6-p3-s17-r3-bgp}}`（属于R2）是由BGP写入的。
    * 去往该地址的下一跳IP地址`{{Lab6-p3-s17-r3-ospf}}`（属于R4）是由OSPF写入的。

    {{Lab6-p3-s17-r3_route_table}}

    R4的路由表：观察得知，由于R4上缺少相应的路由，因此不能Ping通。默认情况下，未启用同步功能，BGP就不会考虑AS内部是否存在相关路由，导致路由黑洞。

    {{Lab6-p3-s17-r4_route_table}}

    

18. 打开R3、R5的BGP同步功能（命令：`synchronization`），等一会儿查看R3、R1到达R2-R8间子网的BGP最佳路由是否发生变化。用Ping测试R1到达R2-R8互联端口的联通性，并跟踪路由。

    R3的配置命令：

    ```kotlin
    {{Lab6-p3-s18-r3_sync_config}}
    ```

    R5的配置命令：
    
    ```kotlin
    {{Lab6-p3-s18-r5_sync_config}}
    ```
    
    R3的BGP数据库：观察得知，
    
    * 到达R2-R8间子网的路由有`{{Lab6-p3-s18-r3-count}}`条
    * 其中最佳路由的下一跳为`{{Lab6-p3-s18-r3-nh}}`（属于R1），因为同步功能打开后，BGP判断AS内部缺少相应的路由，因此不选择本AS作为转发路径。
    
    {{Lab6-p3-s18-r3_bgp_sync}}
    
    R3的路由表：到达R2-R8间子网的下一跳IP为`{{Lab6-p3-s18-r3-rt-ip}}`，属于路由器`{{Lab6-p3-s18-r3-rt-router}}`。
    
    {{Lab6-p3-s18-r3_route_sync}}
    
    R1的BGP数据库：观察得知，
    
    * 到达R2-R8间子网的最佳路由的下一跳为`{{Lab6-p3-s18-r1-nh}}`
    * 属于路由器`{{Lab6-p3-s18-r1-router}}`。由于使用了水平分裂方式，R3并没有向R1报告关于这个子网的路由，因为R3选的下一跳是R1。
    
    {{Lab6-p3-s18-r1_bgp_sync}}
    
    Ping结果：
    
    {{Lab6-p3-s18-ping_sync}}
    
    路由跟踪结果：观察得知，依次经过了这些路由器：`{{Lab6-p3-s18-tr1}}`、`{{Lab6-p3-s18-tr2}}`、`{{Lab6-p3-s18-tr3}}`、`{{Lab6-p3-s18-tr4}}`。
    
    {{Lab6-p3-s18-traceroute_sync}}



19. 在R3、R5的OSPF协议中启用BGP重分发功能（命令：`router ospf [pid]`，`redistribute bgp [AS-number] subnets`），等一会儿，查看R3、R5的OSPF数据库，以及R4的路由表是否出现了AS外部的路由信息。

    R3的配置命令：

    ```kotlin
    {{Lab6-p3-s19-r3_redist_config}}
    ```
    

    R5的配置命令：

    ```kotlin
    {{Lab6-p3-s19-r5_redist_config}}
    ```

    R3的OSPF数据库：观察得知，OSPF从BGP中重分发了AS外部链路的信息，但是R3-R1的直连网络`{{Lab6-p3-s19-r3-net}}`没有被本路由器重分发。
    
    {{Lab6-p3-s19-r3_ospf_db}}
    
    R5的OSPF数据库：观察得知，OSPF从BGP中重分发了AS外部链路的信息，但是R5-R2的直连网络`{{Lab6-p3-s19-r5-net}}`没有被本路由器重分发。
    
    {{Lab6-p3-s19-r5_ospf_db}}
    
    R4的路由表：观察得知，R4上增加了AS外部的路由信息。此时，到达R2-R8间子网的下一跳为`{{Lab6-p3-s19-r4-nh1}}`和 `{{Lab6-p3-s19-r4-nh2}}`(优先级相同)。因为重分发后，OSPF将在AS内部传播BGP的外部路由信息。
    
    {{Lab6-p3-s19-r4_route_redist}}


​    

20. 在R3上清除BGP信息（命令：`clear ip bgp *`），等待一段时间后，在R1上查看到达R2-R8间子网的最佳BGP路由，以及R1的路由表，并在R1上跟踪到达R2-R8间子网的路由。

    R1的BGP数据库：观察得知，

    * 到达R2-R8间子网的路由有`{{Lab6-p3-s20-count}}`条
    * 其中最佳路由的下一跳为`{{Lab6-p3-s20-nh}}`（属于路由器`{{Lab6-p3-s20-router}}`）。

    {{Lab6-p3-s20-r1_bgp_clear}}

    R1的路由表：到达R2-R8间子网的下一跳IP为`{{Lab6-p3-s20-rt-ip}}`，属于路由器`{{Lab6-p3-s20-rt-router}}`。

    {{Lab6-p3-s20-r1_route_clear}}

    路由跟踪结果：观察得知，依次经过了这些路由器：`{{Lab6-p3-s20-tr1}}`、`{{Lab6-p3-s20-tr2}}`、`{{Lab6-p3-s20-tr3}}`、`{{Lab6-p3-s20-tr4}}`。

    {{Lab6-p3-s20-traceroute_clear}}

    

21. 在R3上的BGP中启用OSPF路由重分发功能（命令：router bgp [AS-bnumber], redistribute ospf [pid]），然后查看R3的BGP数据库，标记新增的路由信息。等待一会，在R8上查看AS 65003的内部相关路由信息是否存在。

    R3的配置命令：

    ```kotlin
    {{Lab6-p3-s21-r3_bgp_redist_config}}
    ```
    
    R3的BGP数据库：观察得知，新增的路由分别是：`{{Lab6-p3-s21-net1}}`、`{{Lab6-p3-s21-net2}}`、`{{Lab6-p3-s21-net3}}`。因为重分发后，BGP将在AS之间传播OSPF的内部路由信息。
    
    {{Lab6-p3-s21-r3_bgp_ospf_redist}}
    
    R8的BGP数据库：观察得知，AS 65003内部子网的路由有`{{Lab6-p3-s21-r8-count}}`条，其中到达R3的回环口的最佳路由的下一跳为`{{Lab6-p3-s21-r8-r3}}`，到达R4的回环口的最佳路由的下一跳为`{{Lab6-p3-s21-r8-r4}}`。
    
    {{Lab6-p3-s21-r8_bgp_as65003}}
    
    
    
22. 激活R1上的f0/0端口，配置IP地址，宣告BGP直连网络。配置PC1的IP地址和默认网关。

    R1的配置命令：

    ```kotlin
    {{Lab6-p3-s22-r1_pc_config}}
    ```
    
    PC1的配置命令：
    
    ```kotlin
    {{Lab6-p3-s22-pc1_config}}
    ```

    
    
23. 激活R2上的f0/0端口，配置IP地址，宣告BGP直连网络。配置PC3的IP地址和默认网关。测试PC1-PC3之间的连通性。

    R2的配置命令：

    ```kotlin
    {{Lab6-p3-s23-r2_pc_config}}
    ```
    
    PC3的配置命令：
    
    ```kotlin
    {{Lab6-p3-s23-pc3_config}}
    ```

    Ping结果截图：
    
    {{Lab6-p3-s23-pc1_pc3_ping}}

    

### Part 4. 路由过滤

24. 查看R7的BGP数据库中PC3所在子网的最佳路由。

    R7的BGP数据库：当前，到达PC3子网的最佳路由的下一跳是`{{Lab6-p4-s24-r7}}`。

    {{Lab6-p4-s24-r7_bgp_before_filter}}

    

25. 在R8上创建访问列表（命令：`access-list [id] deny [subnet] [mask]`），配置路由过滤（命令：`neighbor [router-id] distribute-list [access-list-id] out`），用于抑制向R7传播关于PC3子网的更新（这样可以实现前往PC3子网的数据不经过AS 65008），等待一段时间后再次查看R7、R8的BGP数据库中PC3所在子网的最佳路由（可以通过命令`clear ip bgp \*`强制更新）。

    R8的配置命令：

    ```kotlin
    {{Lab6-p4-s25-r8_filter_config}}
    ```

    查看R8生效的访问列表：（访问列表是有顺序的，前面优先。如需修改，请全部删除后重新按顺序添加）

    {{Lab6-p4-s25-r8_access_list}}
    
    R8的BGP数据库：

    {{Lab6-p4-s25-r8_bgp_after_filter}}

    R7的BGP数据库：
    
    {{Lab6-p4-s25-r7_bgp_after_filter}}

    观察得知：R8上到达PC3子网的最佳路由的下一跳是`{{Lab6-p4-s25-r8}}`，该路由被过滤，没有传递给R7，因此，R7上到达PC3子网的最佳路由的下一跳是`{{Lab6-p4-s25-r7}}`，数据不再经过AS 65008了。
    
    

### Part 5. IPv6双栈路由

26. 激活R1上的f0/1端口，配置IPv6的site-local地址；给f2/0口配置IPv6的site-local地址。查看IPv6接口（命令：`show ipv6 interface`），标记自动分配的link-local地址。

    R1的配置命令：

    ```kotlin
    {{Lab6-p5-s26-r1_ipv6_config}}
    ```
    
    查看R1的IPv6接口：
    
    {{Lab6-p5-s26-r1_ipv6_if}}
    
    观察得知：
    
	* 系统为f0/1端口自动分配的链路本地地址为`{{Lab6-p5-s26-f01}}`。
    * 系统为f2/0端口自动分配的链路本地地址为`{{Lab6-p5-s26-f20}}`。

    

27. 给R6的f2/0、f0/1端口配置IPv6的site-local地址，查看IPv6接口，标记自动分配的link-local地址。在R1上分别测试到R6的site-local和link-local地址的连通性。

    R6的配置命令：

    ```kotlin
    {{Lab6-p5-s27-r6_ipv6_config}}
    ```
    
    查看R6的IPv6接口：
    
    {{Lab6-p5-s27-r6_ipv6_if}}

    观察得知：

    * 系统为f0/1端口自动分配的链路本地地址为`{{Lab6-p5-s27-f01}}`。
	* 系统为f2/0端口自动分配的链路本地地址为`{{Lab6-p5-s27-f20}}`。

    Ping测试结果：
    
    {{Lab6-p5-s27-r1_r6_ping}}



28. 分别在R1、R6上启用IPv6单播路由（命令：`ipv6 unicast-routing`），宣告直连网络，互相设置对方为IPv6邻居。然后查看IPv6单播邻居信息（命令：`show ip bgp ipv6 unicast neighbors`）。

    R1的配置命令：

    ```kotlin
    {{Lab6-p5-s28-r1_ipv6_bgp_config}}
    ```
    
    R6的配置命令：
    
    ```kotlin
    {{Lab6-p5-s28-r6_ipv6_bgp_config}}
    ```
    
    查看R6的IPv6的邻居信息：与IPv6地址`{{Lab6-p5-s28-r6}}`的邻居状态关系已为Established。
    
    {{Lab6-p5-s28-r6_ipv6_neighbor}}
    
    查看R1的IPv6的邻居信息：与IPv6地址`{{Lab6-p5-s28-r1}}`的邻居状态关系已为Established。
    
    {{Lab6-p5-s28-r1_ipv6_neighbor}}
    
    
    
29. 给PC2配置IPv6的site-local地址（系统会自动配置链路本地的地址，并发现本地链路上的默认路由器，因此不需要配置默认路由器）。查看IPv6信息（命令：`show ipv6`），标出链路本地地址及路由器的MAC地址。测试下与R1的连通性。

    PC2的配置命令：

    ```kotlin
    {{Lab6-p5-s29-pc2_ipv6_config}}
    ```
    
    查看PC2的IPv6配置：
    
    {{Lab6-p5-s29-pc2_ipv6_info}}
    
    链路本地地址为：`{{Lab6-p5-s29-link}}`，路由器的MAC地址为：`{{Lab6-p5-s29-mac}}`。
    
    PC2→R1的Ping测试结果：
    
    {{Lab6-p5-s29-pc2_r1_ping}}
    
    
    
30. 给PC5配置IPv6地址。查看IPv6信息，标出链路本地地址及路由器的MAC地址。测试下与R6的连通性。

    PC5的配置命令：

    ```kotlin
    {{Lab6-p5-s30-pc5_ipv6_config}}
    ```

    查看PC5的IPv6配置：

    {{Lab6-p5-s30-pc5_ipv6_info}}

    链路本地地址为：`{{Lab6-p5-s30-link}}`，路由器的MAC地址为：`{{Lab6-p5-s30-mac}}`。

    PC5→R6的Ping测试结果：

    {{Lab6-p5-s30-pc5_r6_ping}}

    

31. 查看R1的IPv6路由表（命令：`show ipv6 route`），标出BGP路由，并测试PC2到PC5的连通性。

    R1的IPv6路由表：

    {{Lab6-p5-s31-r1_ipv6_route}}

    PC2→PC5的Ping测试结果：

    {{Lab6-p5-s31-pc2_pc5_ping}}

    

32. 激活R2上的f0/1端口，配置IPv6的site-local地址；启用IPv6单播路由。给PC4配置IPv6地址，并测试下PC4和R2、PC2的连通性。

    R2的配置命令：

    ```kotlin
    {{Lab6-p5-s32-r2_ipv6_config}}
    ```
    
    PC4的配置命令：
    
    ```kotlin
    {{Lab6-p5-s32-pc4_ipv6_config}}
    ```
    
    PC4→R2的Ping测试结果：
    
    {{Lab6-p5-s32-pc4_r2_ping}}
    
    PC4→PC2的Ping测试结果：此时由于路由器`{{Lab6-p5-s32-router}}`没有`{{Lab6-p5-s32-route}}`的IPv6路由，无法Ping通。
    
    {{Lab6-p5-s32-pc4_pc2_ping}}
    
    
    
33. 分别在R1和R2上创建IPv6隧道（命令：`interface Tunnel [id]`），设置隧道IPv6地址（命令：`ipv6 address [address]/[mask_length]`），设置隧道源接口（命令：`tunnel source [interface-number]`），设置隧道的目标IPv4地址（命令：`tunnel destination [ipv4-address]`），设置隧道模式为手工配置（命令：`tunnel mode ipv6ip`）。两路由器隧道的IPv6地址要在同一个子网，目标地址设置为对方的IPv4接口地址。隧道源接口必须使用配置了IPv4地址的接口。

    R1的配置命令：

    ```kotlin
    {{Lab6-p5-s33-r1_tunnel_config}}
    ```

    R2的配置命令：

    ```kotlin
    {{Lab6-p5-s33-r2_tunnel_config}}
    ```

    

34. 在R1、R2上为对方的IPv6子网设置静态路由（命令：`ipv6 route [ipv6-network] Tunnel [id]`）,下一跳为隧道接口。然后在PC2上测试到PC4之间的连通性。

    R1的配置命令：

    ```kotlin
    {{Lab6-p5-s34-r1_ipv6_static}}
    ```

    R2的配置命令：

    ```kotlin
    {{Lab6-p5-s34-r2_ipv6_static}}
	```

    PC2→PC4的Ping测试结果：

    {{Lab6-p5-s34-pc2_pc4_ping}}

    

35. 在R2上为PC5的子网设置静态路由，下一跳为隧道接口。然后在PC5上测试到PC4之间的连通性。如果不通，查看R6上的路由信息，思考下为什么。

    R2的配置命令：

    ```kotlin
    {{Lab6-p5-s35-r2_pc5_static}}
    ```

    PC5→PC4的Ping测试结果：观察得知，从路由器`{{Lab6-p5-s35-router}}`返回没有路由的错误。

    {{Lab6-p5-s35-pc5_pc4_ping_fail}}

    R6的IPv6路由表：观察得知，R6上没有`{{Lab6-p5-s35-route}}`的路由。

    {{Lab6-p5-s35-r6_ipv6_route}}

    

36. 在R1的BGP中重分发IPv6的静态路由（命令：`redistribute static`），然后查看R6的BGP数据库，标记新出现的R2的IPv6网络路由。再次在PC5上测试到PC4之间的连通性。

    R1的配置命令：

    ```kotlin
    {{Lab6-p5-s36-r1_redist_static}}
    ```

    R6的BGP数据库：

    {{Lab6-p5-s36-r6_bgp_static}}

    R6的路由表：

    {{Lab6-p5-s36-r6_route_static}}

    PC5→PC4的Ping测试结果：

    {{Lab6-p5-s36-pc5_pc4_ping_success}}

37. 整理各路由器的当前运行配置，选择与本实验相关的内容记录在文本文件中，每个设备一个文件，分别命名为R1.txt、R2.txt等，随实验报告一起打包上传。



## 六、实验结果与分析

根据你观察到的实验数据和对实验原理的理解，分别解答以下问题：

- 在AS内部两个BGP邻居是否一定要直接连接？如果不直接连接，它们之间是如何获得到达对方的路由的？需要和OSPF那样建立虚链路吗？

  {{Lab6-q1}}

- 默认情况下，BGP根据什么条件决定最佳路由？

  {{Lab6-q2}}

- 为什么未启用同步时，R1选择AS65003作为到达R2的转发路径时，R3和R5的路由表都存在去往R2的路由，但实际却不能Ping通？

  {{Lab6-q3}}

- 为什么未启用路由重分发时，R4没有外部网络的路由？

  {{Lab6-q4}}

- 为什么PC可以不设置IPv6的默认路由器？路由器可以吗？

  {{Lab6-q5}}

- R1和R2两边的IPv6网络是采用什么技术通过IPv4的网络进行通信的？R6的IPv6网络又是如何实现与R2的IPv6网络通信的？

  {{Lab6-q6}}

  

## 七、讨论、心得

在完成本实验后，你可能会有很多待解答的问题，你可以把它们记在这里，接下来的学习中，你也许会逐渐得到答案的，同时也可以让老师了解到你有哪些困惑，老师在课堂可以安排针对性地解惑。等到课程结束后，你再回头看看这些问题时你或许会有不同的见解：

{{lab6-question}}

在实验过程中你可能会遇到的困难，并得到了宝贵的经验教训，请把它们记录下来，提供给其他人参考吧：

{{lab6-experience}}

你对本实验安排有哪些更好的建议呢？欢迎献计献策：

{{lab6-suggestion}}
