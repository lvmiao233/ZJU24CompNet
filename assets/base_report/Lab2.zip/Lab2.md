<img src="img/cover.jpg" alt="cover" style="zoom:43%;" />

<div align="left">
  <font face="楷体" size = 5>
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp课程名称：</font><font face="楷体" size = 5><u>&nbsp&nbsp&nbsp计算机网络&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp实验名称：<u>&nbsp&nbsp&nbsp使用二层交换机组网&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp姓&nbsp&nbsp&nbsp&nbsp名：</font><font face="楷体" size = 5><u>&nbsp&nbsp&nbsp{{global-name}}&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp学&nbsp&nbsp&nbsp&nbsp院：</font><font face="楷体" size = 5><u>&nbsp&nbsp&nbsp计算机科学与技术学院&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
     &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp系：</font><font face="楷体" size = 5><u>&nbsp&nbsp&nbsp计算机科学与技术系&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
     &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp专&nbsp&nbsp&nbsp&nbsp业：<u>&nbsp&nbsp&nbsp计算机科学与技术&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp学&nbsp&nbsp&nbsp&nbsp号：<u>&nbsp&nbsp&nbsp{{global-student-id}}&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
     &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp指导教师：<u>&nbsp&nbsp&nbsp陆系群&nbsp&nbsp&nbsp</u>
  </font><br/><br/><br/>
    <center>
        <font face="黑体" size = 5>
    报告日期: {{lab2-date}}
  </font>
    </center>
</div>
<div STYLE="page-break-after: always;"></div>

<center>
    <font face="黑体" size=5>
        <b>浙江大学实验报告</b>
    </font><br/><br/><br/></center>
<div align="left">
    <font face="黑体" size=4>
         &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp课程名称：<u>&nbsp&nbsp&nbsp&nbsp计算机网络&nbsp&nbsp&nbsp</u>实验类型:<u>&nbsp&nbsp&nbsp&nbsp综合&nbsp&nbsp&nbsp</u>
        </font><br/><br/>
    <font face="黑体" size=4>
         &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp实验项目名称:<u>&nbsp&nbsp&nbsp&nbsp Lab2:使用二层交换机组网
 &nbsp&nbsp&nbsp</u>
        </font><br/><br/><font face="黑体" size=4>
         &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp学生姓名:<u>&nbsp{{global-name}}&nbsp</u>专业: <u>&nbsp&nbsp 计算机科学与技术&nbsp&nbsp</u>学号: <u>&nbsp{{global-student-id}}&nbsp</u>
        </font><br/><br/><font face="黑体" size=4>
         &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp同组学生姓名:<u>&nbsp{{lab2-teammate}}&nbsp</u>指导老师: <u>&nbsp&nbsp&nbsp&nbsp陆系群&nbsp&nbsp&nbsp&nbsp</u>
        </font><br/><br/><font face="黑体" size=4>
         &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp实验地点:<u>&nbsp&nbsp&nbsp曹光彪西-304 &nbsp&nbsp&nbsp</u>实验日期: <u>&nbsp&nbsp{{lab2-date}}&nbsp&nbsp</u>
    </font><br/></div>





## 一、 实验目的

1. 掌握交换机的工作原理、管理配置方法；

2. 掌握VLAN的工作原理、配置方法；

3. 掌握跨交换机的VLAN Trunk配置方法；

4. 掌握多个交换机的冗余组网、负载平衡的配置方法。

   

## 二、实验内容

* 使用网线连接PC，让PC彼此能够互相Ping通；

* 配置和管理交换机：使用Console线连接交换机，运行Putty等终端软件，对交换机进行配置；

* 通过Telnet远程管理交换机；

* 配置镜像端口，用Wireshark软件抓取交换机各端口的数据；

* 配置VLAN Access端口和VLAN Trunk端口；

* 配置交换机的冗余备份；

* 配置交换机的负载均衡。

  

## 三、主要仪器设备

PC机、路由器、交换机、Console连接线、直联网络线、交叉网络线。



## 四、操作方法与实验步骤

### IOS软件的基本操作：

* 进入特权模式：`enable`；该模式下才能查看重要信息，并可进入配置模式；
* 进入配置模式：`configure terminal`；在这个模式下才可以修改配置；
* 进入到某个接口的配置模式：`interface 接口名 模块号/端口号`，例如`interface ethernet 0/1`；
* 命令可以不输全，只要能够被唯一识别；
* 输入？可以显示当前上下文环境下可用命令；
* 在命令后面输入？可以显示命令的参数提示；
* 输入命令的前一部分，再按`tab`，可以自动完成完整的命令输入；
* 按上箭头可以重复输入上次打过的命令；
* 鼠标左键选择需要截取的文本内容，鼠标右键粘贴复制好的文本的内容。

 

### Part 1. 单交换机

1. 用1台二层交换机和4台PC组成一个小型局域网

   a)  使用直联网络线，将每个PC机都连接到交换机的不同端口；

   b)  使用Console线，连接到交换机的Console端口和控制台PC的串口，并在控制台PC上运行Putty等终端软件；

   c)  观察交换机的每个端口状态指示，确认PC机都正确连接到了交换机的端口；

   d)  查看当前哪些端口已连接，哪些端口未连接，连接的速率和模式，收发统计；

   e)  在控制台输入命令查看当前设置了哪些VLAN，缺省所有的端口都属于同一个VLAN 1，如果有端口属于非默认VLAN，输入命令取消该VLAN；

   f)  在每个PC机上互相用Ping来测试连通性，验证局域网已经建立；

   g)  手工关闭某个端口，然后查看端口关闭后的效果，在对应的PC机上使用Ping测试连通性；

   h)  给交换机配置一个IP地址，并在交换机上用Ping命令测试与PC间的连通性；

   i)  在非控制台PC机上，通过telnet连接交换机，进行远程配置。

2. 设置交换机的镜像端口

   a)  确定某个PC（假设为PC1）连接的端口为镜像端口；

   b)  在该PC机上运行包捕获软件，抓取数据包；

   c)  在其他2个PC机上运行Ping，互相测试彼此的连通性；

   d)  查看是否能抓取到其他2个PC机之间的Ping响应包，正常情况下，由于交换机是根据MAC地址直接转发的，所以PC1是收不到其他PC之间的响应包；

   e)  在交换机上将连接PC1的端口配置为镜像端口，被镜像的端口分别为另外2个PC连接的端口；

   f)  在PC1上再次启动包捕获软件，抓取数据包；

   g)  在其他PC机上运行Ping，测试彼此的连通性；

   h)  查看是否能抓取到其他2个PC机之间的Ping响应包。镜像端口设置后，交换机将把被镜像的源端口收发数据复制一份给镜像目的端口。同时该端口的正常收发功能关闭。

3. 在交换机上设置VLAN

   a)  输入命令，在交换机上增加1个新的VLAN；

   b)  将PC3和PC4加入新的VLAN；

   c)  通过PING验证PC之间的连通性；

4. 如果交换机上有密码，请按照下面的步骤清除密码：

   a)  用控制线连接PC和交换机的Console口，PC上运行Putty软件；

   b)  断开交换机电源，然后按住交换机的mode键不放，重新打开交换机电源，直到mode灯闪烁十秒左右后再放开mode键；

   c)  在Putty软件上观察交换机启动过程，直到出现`Switch:`的提示符；

   d)  输入`dir flash:`查看是否存在config.text文件，如果不能列出目录，输入命令`flash_init`，待flash加载成功后再输入命令`rename flash: config.text flash: configX.text`将配置文件改名；

   e)  输入命令`reload`或`reset`重新启动。

   

### Part 2. 多交换机

1. 用2台交换设备和4台PC组成一个小型局域网，每个交换机都连接2台PC机；
2. 在交换机上都设置2个VLAN，将每个交换机上的PC都分成2组，各属于1个VLAN；
3. 将两个交换机连起来，设置互联端口为VLAN Trunk模式，并测试同一组VLAN跨交换机的联通性；普通模式的端口只允许一个VLAN的数据通过，VLAN Trunk模式允许多个VLAN数据同时通过一个端口。
4. 用2条网线连接2个交换机，验证Spanning-tree的作用。交换机之间自动会运行Spanning-tree协议，避免产生转发回路。如果关闭Spanning-tree,存在物理回路的网络很容易产生广播风暴，从而导致网络瘫痪。
5. Spanning-tree是按照VLAN进行管理的，不同VLAN的Spanning-tree可以有不同的设置，因此，可以利用这点实现在两个交换机上的负载平衡。测试2条网线均连接时，数据是否从2条网线分别传送，而当1条网线断开时，数据是否全部改从另外1条网线和传送。

 

## 五、实验数据记录和处理

> [!NOTE]
>
> 以下实验记录均需结合屏幕截图，进行文字标注和描述，图片应大小合适、关键部分清晰可见，可直接在图片上进行标注，也可以单独用文本进行描述。

###  Part 1

1. ##### 在实验拓扑图上标记交换机的IP地址、PC的IP地址及所属VLAN、交换机的与PC的连接端口）

   拓扑图：

   {{Lab2-s1-topology}}

2. ##### 找一台有串口的PC机和一根串口控制线，将控制线的一头连接交换机的Console口，另一头连接PC机的串口。

   在PC机上运行Putty软件，选择Serial方式，默认为9600, COM1。按两下回车，检查是否已经连上交换机。并输入`enable`命令进入到特权模式。如果有密码，请参考第四章的第4小节进行密码清除。 

   输入命令`show version`查看当前交换机型号信息并记录：

   设备型号：`{{Lab2-s2-device-model}}`，IOS软件版本：`{{Lab2-s2-ios-version}}`，

   软件映像文件名：`{{Lab2-s2-image-file}}`，端口数量：`{{Lab2-s2-port-count}}`。

 

3. ##### 输入命令`show flash`: 查看当前文件系统的内容：

   {{Lab2-s3-flash}}

4. ##### 显示交换机的VLAN数据（命令`show vlan`），所有的端口应该都属于VLAN 1。（如果存在其他VLAN，先通过命令`no vlan id`删除）

   {{Lab2-s4-vlan}}

5. ##### 用直连网线（straight through）将PC按照前述拓扑结构连接到交换机。然后给各PC配置IP地址，并用Ping检查各PC之间的联通性，确保都能Ping通，否则请检查网线连接。

   ###### 手工关闭某端口（命令：`shutdown`)，输入命令查看该端口状态（命令：`show interface端口号`，如`show interface e0/1`），在其他PC上使用Ping命令检测连接在该端口的PC是否能够联通。

   命令输出截图：

   {{Lab2-s5-interface-status}}

   Ping结果截图：

   {{Lab2-s5-ping-result}}

6. ##### 重新打开该端口（命令：`no shutdown`），输入命令查看交换机上端口状态。使用Ping命令检测连接在该端口的PC是否能够联通。

   命令输出截图：

   {{Lab2-s6-interface-up}}

   Ping结果截图：

   {{Lab2-s6-ping-success}}

7. ##### 进入VLAN1接口配置模式（命令：`interface vlan 1`），给VLAN 1配置IP地址即是给交换机配置管理IP地址（命令：`ip address 地址 掩码`）。测试PC是否能Ping通交换机的IP地址；如果不通，查看VLAN 1端口的状态是否是up，如果不是，则打开VLAN端口（`no shutdown`）。

   输入的命令：

   ```
   {{Lab2-s7-cmd}}
   ```

   

8. ##### 输入以下命令：打开虚拟终端（命令`line vty 0 4`），允许远程登录（命令： `login`），设置登密码（命令：`password 密码`）

   命令截图：

   {{Lab2-s8-telnet-config}}

9. ##### 在PC上运行Putty软件，选择telnet协议，输入交换机的IP地址，通过网络远程连接交换机，并输入密码。

   连接成功的截图：

   {{Lab2-s9-telnet-success}}

10. ##### 在PC1上运行Wireshark，在另外2台（PC2、PC3）上互相持续的Ping（运行`ping IP地址 -t`），观察在PC1上是否能抓取到PC2和PC3发出的ARP广播包以及ICMP响应包。如果不能抓取到PC2、PC3发送的ARP广播包，在PC2、PC3上先运行`arp –d *`删除所有主机的ARP缓存。正常情况下，ICMP响应包是不能被抓取到的。

    抓包截图：

    {{Lab2-s10-wireshark-capture}}

11. ##### 选择一个交换机端口配置为镜像端口（命令：`monitor session 1 destination interface 端口`），将PC1的网线切换到该端口，将PC2和PC3所连端口配置为被镜像端口（命令：`monitor session 1 source interface 端口`）。继续运行Wireshark，观察在PC1上是否能抓取到PC2和PC3的ICMP响应包。

    输入的命令：

    ```
    {{Lab2-s11-cmd}}
    ```

    抓包截图：

    {{Lab2-s11-mirror-capture}}

12. ##### 关闭PC1端口的镜像功能（命令：`no monitor session 1 destination interface 端口`)，否则该端口不能正常收发数据。

    输入的命令：

    ```
    {{Lab2-s12-cmd}}
    ```

    

13. ##### 在交换机上增加VLAN 2（命令：`vlan database`或`config terminal`，`vlan 2`），将PC3、PC4所连端口加入到VLAN 2（命令：`interface 端口`，`switchport access vlan 2`）。用Ping检查PC之间的联通性（同一VLAN的PC之间能够通，不同VLAN的PC之间不能通）。

    输入的命令：

    ```
    {{Lab2-s13-cmd}}
    ```

    联通性检测截图：

    * PC1→PC2

      {{Lab2-s13-ping-pc12}}

    * PC1→PC3

      {{Lab2-s13-ping-pc13}}

    * PC4→PC2
    
      {{Lab2-s13-ping-pc42}}
    
    * PC4→PC3
    
      {{Lab2-s13-ping-pc43}}

 

14. ##### 查看交换机上的运行配置（命令`show running-config`），复制粘贴本节相关的文本。

    运行配置文本：

    ```
    {{Lab2-s14-config}}
    ```



### Part 2

15. ##### 增加一台交换机（Switch2），将PC2、PC4连接到该交换机，并用一根交叉网线（Cross-over）将两个交换机连接起来。在拓扑图上记录各PC的IP地址、连接端口及所在VLAN：

    拓扑图：

    {{Lab2-s15-topology}}

    ##### 在Switch2上增加VLAN 2，将PC4所连端口加入到VLAN 2。用Ping检查不同交换机上属于同一VLAN的PC之间的联通性（即PC1与PC2应该通，PC3与PC4不能通）。然后显示2个交换机的VLAN数据（命令`show vlan`)

    Switch1的vlan数据：

    {{Lab2-s15-switch1-vlan}}

    Switch2的vlan数据：

    {{Lab2-s15-switch2-vlan}}

    联通性检测截图：

    * PC1→PC2

      {{Lab2-s15-ping-pc12}}

    * PC3→PC4

      {{Lab2-s15-ping-pc34}}

 

16. ##### 将交换机之间的互联端口配置为VLAN Trunk模式（命令：`switchport mode trunk`，部分型号的设备可能要先设置封装协议，命令：`switchport trunk encapsulation dot1q`），再次用Ping检查属于同一VLAN但在不同交换机的PC之间的联通性（即PC1与PC2应该通，PC3与PC4也应该通）。

    输入的命令：

    ```
    {{Lab2-s16-cmd}}
    ```

    联通性检测截图：

    * PC1→PC2

      {{Lab2-s16-ping-pc12}}
    
    * PC3→PC4
    
      {{Lab2-s16-ping-pc34}}

  

17. ##### 再增加一根网线，把2个交换机的另外2个端口连接起来。并将这2个端口都配置成VLAN Trunk模式。稍等片刻，查看4个互联端口的状态（命令：`show spanning-tree`），分别在2个VLAN中标出: 哪个交换机是根网桥？哪些端口处于转发状态（FWD），哪些端口处于阻塞状态（BLK）。

    Spanning-tree数据截图：

    {{Lab2-s17-switch1-stp}}
    
    {{Lab2-s17-switch2-stp}}

 

18. ##### 关闭2个VLAN的STP（命令：`no spanning-tree vlan ID`），观察两个交换机的端口状态指示灯（急速闪动），并在PC上用Ping测试网络的延迟是否加大（甚至可能出现超时或丢包）。

    Ping结果截图：

    {{Lab2-s18-ping-delay}}

19. ##### 重新打开2个VLAN的STP（命令：`spanning-tree vlan ID`）, 观察两个交换机的端口状态指示灯（缓慢闪动），并在PC上用Ping测试网络的延迟是否恢复正常。

    Ping结果截图：

    {{Lab2-s19-ping-recovery}}

20. ##### 拔掉连接在2个处于FWD状态端口之间的网线，等待一会儿，查看4个互联端口的状态（命令：`show spaning-tree`）（有些端口可能已经消失）。标出原BLK状态的端口是否变成了FWD状态。

    Spanning-tree数据截图：

    {{Lab2-s20-switch1}}

    {{Lab2-s20-switch2}}

21. ##### 配置2个交换机的互联端口优先级(默认优先级128)，使VLAN1的数据优先通过第1对互联端口传送（命令：`interface 端口`, `spanning-tree vlan 1 port-priority 16`）。使VLAN2的数据优先通过第2对互联端口传送（命令：`interface 端口`, `spanning-tree vlan 2 port-priority 16`）。此处只记录2个交换机各自所使用的命令及参数即可。

    输入的命令：

    * Switch1：

      ```
      {{Lab2-s21-switch1-cmd}}
      ```
    
    * Switch2：
    
      ```
      {{Lab2-s21-switch2-cmd}}
      ```



22. ##### 拔掉剩下的1根连接互联端口的网线，稍后2根网线重新插上，等待一会儿，查看4个互联端口的状态，分别在2个VLAN中标出:各端口的优先级，哪些端口处于转发状态，哪些端口处于阻塞状态。

    Spanning-tree数据截图：

    {{Lab2-s22-switch1}}

    {{Lab2-s22-switch2}}

23. ##### 拔掉其中1根连接互联端口的网线，查看4个互联端口中原先处于BLK状态的端口，是否变成了FWD状态（哪个VLAN发生了变化）

    Spanning-tree数据截图：

    {{Lab2-s23-switch1}}

    {{Lab2-s23-switch2}}

24. ##### 记录2个交换机上的运行配置（命令:`show running-config`），复制粘贴本节相关的文本（完整的内容请放在文件中，每个交换机一个文件，分别命名为S1.txt、S2.txt）。

    运行配置文本：

    * Switch1：

      ```
      {{Lab2-s24-switch1}}
      ```

    * Switch2：

      ```
      {{Lab2-s24-switch2}}
      ```

      

## 六、实验结果与分析

根据你观察到的实验数据和对实验原理的理解，分别解答以下问题：

* 端口状态显示为administratively down，意味着什么意思？

  {{Lab2-analysis-q1}}

* 在交换机配置为镜像端口前，为什么可以抓取到其他PC之间的ARP请求包，而不能抓取ARP响应包？ 

  {{Lab2-analysis-q2}}

* PC属于哪个VLAN，是由PC自己可以配置的，还是由交换机决定的？

  {{Lab2-analysis-q3}}

* 同一个VLAN的PC，如果配置了不同长度的子网掩码，能够互相Ping通吗？

  {{Lab2-analysis-q4}}

* 为什么在划分为2个VLAN后，两组PC之间就不能进行IP通信了呢？

  {{Lab2-analysis-q5}}

* 交换机在VLAN Trunk模式下使用的封装协议是什么？

  {{Lab2-analysis-q6}}

* 未启用STP（Spanning Tree Protocol）协议时，交换机之间连接了多条网线后，为什么Ping测试的响应会延迟很大甚至超时？

  {{Lab2-analysis-q7}}

* 从插上网线后开始，交换机的端口状态出现了哪些变化？大约需要多少时间才能成为FWD状态？期间，连接在该端口的计算机是否能够Ping通？

  {{Lab2-analysis-q8}}



## 七、讨论、心得

在完成本实验后，你可能会有很多待解答的问题，你可以把它们记在这里，接下来的学习中，你也许会逐渐得到答案的，同时也可以让老师了解到你有哪些困惑，老师在课堂可以安排针对性地解惑。等到课程结束后，你再回头看看这些问题时你或许会有不同的见解：

 {{lab2-question}}

在实验过程中你可能会遇到的困难，并得到了宝贵的经验教训，请把它们记录下来，提供给其他人参考吧：

{{lab2-experience}}

你对本实验安排有哪些更好的建议呢？欢迎献计献策：

{{lab2-suggestion}}
