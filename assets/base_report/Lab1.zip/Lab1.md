



<img src="./img/cover.jpg" alt="cover" style="zoom:43%;" />

<left>
  <font face="楷体" size = 5>
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp课程名称：</font><font face="楷体" size = 5><u>&nbsp&nbsp&nbsp计算机网络&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp实验名称：<u>&nbsp&nbsp&nbsp网络协议分析&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp姓&nbsp&nbsp&nbsp&nbsp名：</font><font face="楷体" size = 5><u>&nbsp&nbsp&nbsp 姓名&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp学&nbsp&nbsp&nbsp&nbsp院：</font><font face="楷体" size = 5><u>&nbsp&nbsp&nbsp计算机科学与技术学院&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
     &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp系：</font><font face="楷体" size = 5><u>&nbsp&nbsp&nbsp计算机科学与技术系&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
     &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp专&nbsp&nbsp&nbsp&nbsp业：<u>&nbsp&nbsp&nbsp计算机科学与技术&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp学&nbsp&nbsp&nbsp&nbsp号：<u>&nbsp&nbsp&nbsp学号&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
     &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp指导教师：<u>&nbsp&nbsp&nbsp陆系群&nbsp&nbsp&nbsp</u>
  </font><br/><br/><br/>
    <center><font face="黑体" size = 5>
    报告日期: 2024年月日
  </font>
</left>
<div STYLE="page-break-after: always;"></div>

<center>
    <font face="黑体" size=5>
        <b>浙江大学实验报告</b>
    </font><br/><br/><br/></center>
<left>  
    <font face="黑体" size=4>
         &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp课程名称：<u>&nbsp&nbsp&nbsp&nbsp计算机网络&nbsp&nbsp&nbsp</u>实验类型:<u>&nbsp&nbsp&nbsp&nbsp综合&nbsp&nbsp&nbsp</u>
        </font><br/><br/>
    <font face="黑体" size=4>
         &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp实验项目名称:<u>&nbsp&nbsp&nbsp&nbsp Lab1:网络协议分析
 &nbsp&nbsp&nbsp</u>
        </font><br/><br/><font face="黑体" size=4>
         &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp学生姓名:<u>&nbsp&nbsp  &nbsp</u>专业: <u>&nbsp&nbsp 计算机科学与技术&nbsp&nbsp</u>学号: <u>&nbsp&nbsp &nbsp&nbsp</u>
        </font><br/><br/><font face="黑体" size=4>
         &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp同组学生姓名:<u>&nbsp&nbsp&nbsp&nbsp  &nbsp&nbsp&nbsp</u>指导老师: <u>&nbsp&nbsp&nbsp&nbsp陆系群&nbsp&nbsp&nbsp&nbsp</u>
        </font><br/><br/><font face="黑体" size=4>
         &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp实验地点:<u>&nbsp&nbsp&nbsp曹光彪西-304 &nbsp&nbsp&nbsp</u>实验日期: <u>&nbsp&nbsp 2024年月日&nbsp&nbsp</u>
    </font><br/></left>



## 一、实验目的

* 学习使用Wireshark抓包工具
* 观察和理解常见网络协议的交互过程
* 理解数据包分层结构和格式

 

## 二、实验内容

* Wireshark是PC上使用最广泛的免费抓包工具，可以分析大多数常见的协议数据包。有Windows版本和Mac版本，可以免费从网上下载。
* 掌握网络协议分析软件Wireshark的使用，学会配置过滤器
* 观察所在网络出现的各类网络协议，了解其种类和分层结构
* 观察捕获到的数据包格式，理解各字段含义 
* 根据要求配置Wireshark，捕获某一类协议的数据包，并分析解读

 

## 三、主要仪器设备

* 联网的PC机、Windows、Linux或Mac操作系统、浏览器软件
* WireShark协议分析软件

 

## 四、操作方法与实验步骤

* 安装网络包捕获软件Wireshark
* 配置网络包捕获软件，捕获所有机器的数据包
* 观察捕获到的数据包，并对照解析结果和原始数据包
* 配置网络包捕获软件，只捕获特定IP或特定类型的包
* 抓取以下通信协议数据包，观察通信过程和数据包格式
  * PING：测试一个目标地址是否可达
  * TRACE ROUTE：跟踪一个目标地址的途经路由
  * NSLOOKUP：查询一个域名
  * HTTP：访问一个网页

提醒：为了避免捕获到大量无关数据包，影响实验观察，建议关闭所有无关软件。实验之前可以提前了解下第六部分有哪些问题。

 

## 五、 实验数据记录和处理

> [!NOTE]
>
> 以下实验记录均需结合屏幕截图，进行文字标注和描述，图片应大小合适、关键部分清晰可见，可直接在图片上进行标注，也**可以单独用文本进行描述**。

### Part One

1. 运行**Wireshark**软件，开始捕获数据包，列出你看到的协议名字（至少**5**个）。

   协议名：`{{lab1-q1-protocols}}`

2. 找一个包含**IP**的数据包，这个数据包有`{{lab1-packet-analysis-layer-count}}`层？最高层协议是`{{lab1-packet-analysis-top-protocol}}`，从**Ethernet**开始往上，各层协议的名字分别为`{{lab1-q2-protocol-names}}`。

   展开**IP**层协议，标出源**IP**地址、目标**IP**地址及其在数据包中的具体位置，展开**Ethernet**层，标出源**MAC**地址和目标**MAC**地址及其在数据包中的具体位置。

   截图参考（此处应替换成实际截获的数据）：

   ![img](img/1.1.jpg)

3. 配置应用显示过滤器，让界面只显示某一协议类型的数据包（输入协议名称）。

   | 使用的过滤器 | 希望显示的协议类型 |
   | :----------: | :----------------: |
   |  {{lab1-filter-used-protocol}}   |   {{lab1-filter-protocol-type}}    |

   截图：

   

4. 配置应用显示过滤器，让界面只显示某个**IP**地址的数据包（`ip.addr==x.x.x.x`）。

   | 使用的过滤器 | 希望显示的IP地址 |
   | :----------: | :--------------: |
   |  {{lab1-filter-used-ip}}  |  {{lab1-filter-ip-addres}}   |

   截图：

   

5. 配置捕获过滤器，只捕获某个**IP**地址的数据包（`host x.x.x.x`）。

   | 使用的过滤器 | 希望捕获的IP地址 |
   | :----------: | :--------------: |
   |   {{lab1-task5-filter}}    |  {{lab1-task5-protocol}}   |

   截图：

   

6. 配置捕获过滤器，只捕获某类协议的数据包（`tcp port xx` 或者`udp port xx`）。

   | 使用的过滤器 | 希望捕获的协议类型 |
   | :----------: | :----------------: |
   |  {{lab1-task6-filter}}    |  {{lab1-task6-protocol}}   |

   截图：

   

> [!NOTE]
>
> 请在下面的每次捕获任务完成后，保存Wireshark抓包记录（.pcap格式），随报告一起提交。
>
> 每一个任务一个单独文件（如dns.pcap、ping.pcap、tracert.pcap），请捕获尽可能短的时间，以免文件大小超过系统限制。

### Part Two

任务1：使用nslookup命令，查询某个域名，并捕获这次的数据包。

DNS数据包由哪几层协议构成？`{{lab1-dns-protocols}}`。 使用的服务方端口是：`{{lab1-dns-ports}}` 。



分别选择一个请求包和一个响应包，展开最高层协议的详细内容，标出交易ID、查询类型、查询的域名内容以及查询结果。

截图参考（此处应替换成实际截获的数据，请求和响应各一个）：

![img](img/1.2.jpg)



任务2：使用Ping命令，分别测试某个IP地址和某个域名的连通性，并捕获数据包。捕获到了哪些相关协议数据包？

Ping IP地址时：`{{lab1-ping-ip-protocols}}`

Ping域名时：`{{lab1-ping-domain-protocols}}`

ICMP数据包分别由哪几层协议构成？ `{{lab1-icmp-layers}}`

分别选择一个ARP请求和响应数据包，展开最高层协议的详细内容，标出操作码、发送者IP地址、发送者MAC地址、查询的目标IP地址、Ethernet层的目标MAC地址以及查询结果。

截图参考（此处应替换成实际截获的数据，请求和响应各一）：

{{image:lab1-ping-screenshot}}



分别选择一个ICMP请求和响应数据包，展开最高层协议的详细内容，标出类型、序号。

截图参考（此处应替换成实际截获的数据，请求和响应各一）：

![img](img/1.4.jpg)



任务3：使用Tracert命令（Mac下使用Traceroute命令），跟踪某个外部IP地址的路由，并捕获这次的数据包。

跟踪路由使用的数据包协议类型是：`{{lab1-tracert-protocol}}`，数据包由几层协议构成？`{{lab1-tracert-layers}}`。

观察并记录请求包中IP协议层的TTL字段变化规律，第一个请求的TTL等于`{{lab1-tracert-ttl-start}}`，同样TTL的请求连续发送了`{{lab1-tracert-ttl-repeats}}`个，然后每次TTL增加了`{{lab1-tracert-ttl-increment}}`，最后一个请求的TTL等于`{{lab1-tracert-ttl-end}}`。附上截图：

截图参考（此处应替换成实际截获的数据）：

![img](img/1.5.jpg)



观察并记录响应包的信息，第一组响应包的发送者IP是：`{{lab1-tracert-resp-ip-first}}`，标记ICMP层的类型字段。最后一组响应包的发送者IP是：`{{lab1-tracert-resp-ip-last}}`，标记ICMP层的类型字段。附上截图：

截图参考（此处应替换成实际截获的数据）：

第一组：

![img](img/1.6.jpg)

最后一组：

![img](img/1.7.jpg)

 

> [!NOTE]
>
> 请在下面的捕获任务完成后，保存Wireshark抓包记录（.pcap格式），随报告一起提交。文件名http.pcap。

### Part Three

1. 运行ipconfig /flushdns命令清空DNS缓存，然后打开浏览器，访问www.zju.edu.cn，并使用捕获过滤器只捕获访问该网站的数据（过滤器设置：`tcp port 80 `or `udp port 53`），网页完全打开后，停止捕获。

   捕获到的这些最高层的协议数据包分别由哪几层协议构成？

   DNS： `{{lab1-web-dns-layers}}`

   HTTP:  `{{lab1-web-http-layers}}`

   每种协议选取一个代表展开后截图，并标出源和目标IP地址、源和目标端口）

   截图参考（此处应替换成实际截获的数据）：

   ![img](img/1_clip_image0021.jpg)

   ![img](img/1_clip_image2.jpg)
   
    

2. 为了打开网页，浏览器查询了哪些相关的域名？

   域名列表：`{{lab1-web-queried-domains}}`

​                                   

3. 使用显示过滤器`tcp.stream eq X`，让X从0开始变化，直到没有数据。分析浏览器为了获取网页数据，总共建立了几个连接？（一个TCP流对应一个TCP连接）

   TCP连接数：`{{lab1-web-tcp-connections}}`

 

4. 右键点击某个HTTP数据包，选择跟踪TCP流，可以看到HTTP会话的数据。分析浏览器与WEB服务器之间进行了几次HTTP会话（一对HTTP请求和响应对应一次HTTP会话）？注意：一个TCP流上可能存在多个HTTP会话。

   HTTP会话数：`{{lab1-web-http-sessions}}`

 

5. ##### 选择一个HTTP的TCP流进行截图，标出请求和响应部分（最好有多个HTTP会话的）：

   截图示例（此处应替换成实际截获的数据）：

   ![img](img/1_clip_image002.jpg)

 

### 六、实验结果分析与思考

* 如果只想捕获某个特定WEB服务器IP地址相关的HTTP数据包，捕获过滤器应该怎么写？

  {{lab1-analysis-q1}}

* Ping发送的是什么类型的协议数据包？什么情况下会出现ARP数据包？ Ping一个域名和Ping一个IP地址出现的数据包有什么不同？

  {{lab1-analysis-q2}}

* Tracert/Traceroute发送的是什么类型的协议数据包，整个路由跟踪过程是如何进行的？

  {{lab1-analysis-q3}}

* 如何理解TCP连接和HTTP会话？他们之间存在什么关系？

  {{lab1-analysis-q4}}

* DNS为什么选择使用UDP协议进行传输？而HTTP为什么选择使用TCP协议？ 

  {{lab1-analysis-q5}}



### 七、讨论、心得

在完成本实验后，你可能会有很多待解答的问题，你可以把它们记在这里，接下来的学习中，你也许会逐渐得到答案的，同时也可以让老师了解到你有哪些困惑，老师在课堂可以安排针对性地解惑。等到课程结束后，你再回头看看这些问题时你或许会有不同的见解：

 

在实验过程中你可能会遇到的困难，并得到了宝贵的经验教训，请把它们记录下来，提供给其他人参考吧：

 

你对本实验安排有哪些更好的建议呢？欢迎献计献策：

 