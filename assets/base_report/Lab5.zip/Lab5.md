<img src="img/cover.jpg" alt="cover" style="zoom:43%;" />

<div align="left">
  <font face="楷体" size = 5>
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp课程名称：</font><font face="楷体" size = 5><u>&nbsp&nbsp&nbsp计算机网络&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp实验名称：<u>&nbsp&nbsp&nbsp动态路由协议OSPF配置&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp姓&nbsp&nbsp&nbsp&nbsp名：</font><font face="楷体" size = 5><u>&nbsp&nbsp&nbsp{{global-name}}&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp学&nbsp&nbsp&nbsp&nbsp院：</font><font face="楷体" size = 5><u>&nbsp&nbsp&nbsp计算机科学与技术学院&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
     &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp系：</font><font face="楷体" size = 5><u>&nbsp&nbsp&nbsp计算机科学与技术系&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
     &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp专&nbsp&nbsp&nbsp&nbsp业：<u>&nbsp&nbsp&nbsp计算机科学与技术&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp学&nbsp&nbsp&nbsp&nbsp号：<u>&nbsp&nbsp&nbsp{{global-student-id}}&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
     &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp指导教师：<u>&nbsp&nbsp&nbsp陆系群&nbsp&nbsp&nbsp</u>
  </font><br/><br/><br/>
    <center><font face="黑体" size = 5>
    报告日期: {{lab5-date}}
  </font>
    </center>
</div>
<div STYLE="page-break-after: always;"></div>

<center>
    <font face="黑体" size=5>
        <b>浙江大学实验报告</b>
    </font><br/><br/><br/></center>
<div align="left"> 
    <font face="黑体" size=4>
         &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp课程名称：<u>&nbsp&nbsp&nbsp&nbsp计算机网络&nbsp&nbsp&nbsp</u>实验类型:<u>&nbsp&nbsp&nbsp&nbsp综合&nbsp&nbsp&nbsp</u>
        </font><br/><br/>
    <font face="黑体" size=4>
         &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp实验项目名称:<u>&nbsp&nbsp&nbsp&nbsp Lab5:动态路由协议OSPF配置
 &nbsp&nbsp&nbsp</u>
        </font><br/><br/><font face="黑体" size=4>
         &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp学生姓名:<u>&nbsp{{global-name}}&nbsp</u>专业: <u>&nbsp&nbsp 计算机科学与技术&nbsp&nbsp</u>学号: <u>&nbsp{{global-student-id}}&nbsp</u>
        </font><br/><br/><font face="黑体" size=4>
         &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp同组学生姓名:<u>&nbsp&nbsp&nbsp&nbsp  &nbsp&nbsp&nbsp</u>指导老师: <u>&nbsp&nbsp&nbsp&nbsp陆系群&nbsp&nbsp&nbsp&nbsp</u>
        </font><br/><br/><font face="黑体" size=4>
         &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp实验地点:<u>&nbsp&nbsp&nbsp曹光彪西-304 &nbsp&nbsp&nbsp</u>实验日期: <u>&nbsp&nbsp{{lab5-date}}&nbsp&nbsp</u>
    </font><br/></div>







## 一、实验目的

1.  理解链路状态路由协议的工作原理。
2.  理解OSPF协议的工作机制。
3.  掌握配置和调试OSPF协议的方法。



## 二、实验内容

-   使用网线连接PC和路由器，并配置PC和路由器各端口的IP地址，让PC彼此能够与路由器接口互相Ping通；

-   用网线连接多个路由器，并配置互联端口的IP地址，使直接连接的2个路由器能相互Ping通；

-   在Area 0的路由器上启用OSPF动态路由协议，让各路由器能够互相学习到新的路由信息，进而使区域内的PC能够相互Ping通；
    
-   在Area 1的路由器上启用OSPF动态路由协议，让区域内和区域间各路由器能够互相学习到新的路由信息；
    
-   在Area 2的路由器上启用OSPF动态路由协议，在NBMA（非广播多路访问）网络拓扑上配置OSPF协议，让区域内和区域间各路由器能够互相学习到新的路由信息；
    
-   在Area 3（不与Area 0直接连接）的路由器上启用OSPF动态路由协议，在边界路由器上建立虚链路，让Area
    3的路由器能够学习到新的路由信息，进而使Area 3的路由器能够学习到其他区域的路由信息；
    
-   在上述各种情况下，观察各路由器上的路由表和OSPF运行数据，并验证各PC能够相互Ping通；

-   断开某些链路，观察OSPF事件和路由表变化；

-   在Area边界路由器上配置路由聚合。



## 三、主要仪器设备

PC机、路由器、Console连接线、直联网络线、交叉网络线



## 四、操作方法与实验步骤

-   按照拓扑图连接PC和路由器，其中R1-R2之间采用串口连接，数据链路层协议使用HDLC；R5、R7、R8之间采用Frame Relay交换机连接（Frame Relay交换机的配置请参考GNS3指南）。
    
- 设计好PC和路由器各端口的IP地址、子网掩码。分配地址时请遵循下面的规则：

  * Area 0使用10.0.0.0/16的网络地址进行扩展，每个子网分别使用10.0.0.0/24、10.0.1.0/24、10.0.2.0/24等子网地址。其中点对点连接的路由器之间的子网使用10.0.123.240/28进行扩展，可以最大程度的节约地址，例如使用串行掩码方案，网络地址部分为30位，每个子网刚好有2个可用地址（去掉1个主机地址部分全0的和1个主机地址部分全1的），可以按如下方式进行分配：
    * R1-R2互联接口: 10.0.123.241/30、10.0.123.242/30，子网地址：10.0.123.240/30;
    * R1-R3互联接口: 10.0.123.245/30、10.0.123.246/30，子网地址：10.0.123.244/30;
    * 依次类推，R2、R3、R4、R6之间的子网为（只需要4个地址）：10.0.123.248/29，去掉全0全1地址后，还有6个地址可用。

  * Area 1、Area 2、Area 3使用10.X.0.0/16的网络地址进行扩展，其中X为Area编号，例如Area 1的3个子网分别使用10.1.0.0/24、10.1.1.0/24、10.1.2.0/24等子网地址（同一个交换机上的多台路由器的接口属于同一个子网）。

{{Lab5-p0-s1-topology}}

-   配置各PC的的默认网关，分别设置为所连路由器的相应端口IP地址；

-   配置各路由器互联端口的IP地址，使直连的2个路由器能相互Ping通；

-   先后给路由器R1、R2、R3配置RIP协议和OSPF协议，比较两者选择的路由差别（RIP不考虑线路带宽，只考虑经过的路由器个数，OSPF考虑线路cost，带宽越大，cost越小）；

-   给Area 1、Area 2的路由器配置OSPF协议，观察区域间路由信息交换；

-   给Area 3的路由器配置OSPF协议。由于Area 3没有物理上直接与Area 0连接，所以需要利用Area 1作为中介，在R4和R9之间为Area 3建立一个虚链路。
    
-   观察各路由器的路由表，查看路由器做出的选择是否符合预期；

-   通过Ping检查各PC之间的联通性；

-   实时显示路由器之间交换的路由信息事件，理解OSPF协议交互过程；

-   断开某些网络连接，查看OSPF的数据变化以及路由表的变化，并测试PC间的联通性；

### RIP相关命令参考

-   在路由器上启用RIP协议：`Router(config)# router rip`
-   将路由器各接口（子网）加入路由宣告：`Router(config-router)# network[<ip_net]`

### OSPF相关命令参考

- 给路由器的回环接口配置地址

  ```kotlin
  Router(config)# interface loopback 0
  Router(config-if)# ip address [ip] [mask]
  ```

-   在路由器上启用OSPF协议：`Router(config)# router ospf [process-id]`

-   配置路由器接口（子网）所属Area ID：`Router(config-router)# network [ip_net] [mask] area [area-id]`

-   查看路由器的OSPF数据库（可以查看Router ID）：`Router# show ip ospf database`

- 手工指定Router ID：`Router(config-router)# router-id `

  更换Router ID需要重启路由器或清除OSPF状态才能生效, 其中：

  * 重启路由器命令：`Router# reload`
  * 清除OSPF状态命令：`Router# clear ip ospf process`

-   观察各路由器的OSPF邻居关系，在广播网络中，为减少通信量，会自动选出一个DR（Designated Router）和一个BDR（Backup Designated Router），其他路由器只与DR、BDR成为邻接关系：`Router# show ip ospf neighbor detail`

-   观察路由器的OSPF接口状态（可以查看cost值）：`Router# show ip ospf interface`

- 打开事件调试，实时显示路由器之间交换的路由信息事件：`Router# debug ip ospf events`

  观察完毕后，可以关闭调试信息显示：`Router# no debug ip ospf events`

-   在两个区域边界路由器之间建立虚链路，[area-id]填写用于传递数据的区域ID，[router ID]分别设为对方的Router ID：`Router(config-router)# area [area-id] virtual-link [router ID]`

-   在区域边界路由器上手工进行路由合并：`Router(config-router)# area [area-id] range [ip_net] [mask]`



## 五、实验数据记录和处理

>  [!NOTE]
>
> 以下实验记录均需结合屏幕截图，进行文字标注和描述，图片应大小合适、关键部分清晰可见，可直接在图片上进行标注，也可以单独用文本进行描述。
>
> 记录输入的命令时，直接粘帖文字即可（保留命令前面的提示符，如R1#）。

1. 参考实验操作方法的说明，设计好每个PC、路由器各接口的IP地址及掩码，并标注在拓扑图上。

   设计的拓扑图:

   {{Lab5-p0-s1-topology}}

   

2. 给路由器R1、R2、R3各接口配置IP地址并激活。配置PC1、PC2的IP地址和默认网关，测试PC1与R1、PC2与R2的连通性。

   R1配置命令：

   ```kotlin
   {{Lab5-p0-s2-r1_config}}
   ```
   
   R2配置命令：
   
   ```kotlin
   {{Lab5-p0-s2-r2_config}}
   ```
   
   R3配置命令：
   
   ```kotlin
   {{Lab5-p0-s2-r3_config}}
   ```
   
   Ping测试结果截图
   
   PC1→R1:
   
   {{Lab5-p0-s2-pc1_to_r1}}
   
   PC2→R2:
   
   {{Lab5-p0-s2-pc2_to_r2}}
   
   

### Part 1：配置RIP（用于和OSPF进行比较）

3. 在R1、R2、R3上启用RIP动态路由协议，并宣告各接口所在子网地址（版本要设置成2）；

   R1配置命令：

   ```kotlin
   {{Lab5-p1-s3-rip_r1}}
   ```
   
   R2配置命令：
   
    ```kotlin
    {{Lab5-p1-s3-rip_r2}}
    ```

   R3配置命令：

   ```kotlin
   {{Lab5-p1-s3-rip_r3}}
   ```

   

4. 查看R1、R2、R3的路由表，跟踪PC1到PC2的路由；

   R1路由表（标出到PC2子网的路由，下一跳是哪个路由器）：

   {{Lab5-p1-s4-r1_route}}

   R2路由表（标出到PC1子网的路由，下一跳是哪个路由器）：

   {{Lab5-p1-s4-r2_route}}

   R3路由表：

   {{Lab5-p1-s4-r3_route}}

   PC1→PC2的路由跟踪：（经过的路由器顺序是R1、`{{Lab5-p1-q4-1}}`）
   
   {{Lab5-p1-s4-pc1_to_pc2_trace}}



### Part 2：配置单域OSPF（Area 0）

5. 启用路由器R1的OSPF动态路由协议，并配置各接口所属区域（为Area 0），其中进程ID请设置为学号的后2位（全0者往前取值）。

   R1配置命令：

   ```kotlin
   {{Lab5-p2-s5-r1_ospf}}
   ```
   
   

6. 先给R2的回环接口配置IP地址。然后再启用路由器R2的OSPF动态路由协议，设置包括回环接口在内的各接口所属区域（为Area 0）。

   R2配置命令：

   ```kotlin
   {{Lab5-p2-s6-r2_ospf}}
   ```
   
   
   
7. 启用路由器R3的OSPF动态路由协议，手工指定Router ID，并设置各接口所属区域为Area 0。

   R3配置命令：

   ```kotlin
   {{Lab5-p2-s7-r3_ospf}}
   ```
   
   
   
8. 查看OSPF数据库，并标出各路由器的Router ID。

   R1的OSPF数据库：

   {{Lab5-p2-s8-r1_ospf_db}}

   从上图可知，R1的Router ID为`{{Lab5-p2-q8-1}}`（取自接口`{{Lab5-p2-q8-2}}`的IP）；与R1连接的有`{{Lab5-p2-q8-3}}`个路由器，其ID分别是`{{Lab5-p2-q8-4}}`、`{{Lab5-p2-q8-5}}`， 有`{{Lab5-p2-q8-6}}`条链路，其ID分别是`{{Lab5-p2-q8-7}}`、`{{Lab5-p2-q8-8}}`。

   R2的OSPF数据库：

   {{Lab5-p2-s8-r2_ospf_db}}

   从上图可知，R2的Router ID为`{{Lab5-p2-q8-9}}`（取自接口`{{Lab5-p2-q8-10}}` 的IP）；与R2连接的有`{{Lab5-p2-q8-11}}`个路由器，其ID分别是`{{Lab5-p2-q8-12}}`、`{{Lab5-p2-q8-13}}`， 有`{{Lab5-p2-q8-14}}`条链路，其ID分别是`{{Lab5-p2-q8-15}}`、`{{Lab5-p2-q8-16}}`。

   R3的OSPF数据库：

   {{Lab5-p2-s8-r3_ospf_db}}

   从上图可知，R3的Router ID为`{{Lab5-p2-q8-17}}`；与R3连接的有`{{Lab5-p2-q8-18}}`个路由器，其ID分别是`{{Lab5-p2-q8-19}}`、`{{Lab5-p2-q8-20}}`， 有`{{Lab5-p2-q8-21}}`条链路，其ID分别是`{{Lab5-p2-q8-22}}`、`{{Lab5-p2-q8-23}}`。

   

9. 在路由器R1上显示OSPF接口数据（命令：`show ip ospf interface`），标记各接口的cost值，网络类型，邻接关系及其Router ID，广播类型的网络再标出DR（Designed Router）或者BDR（Backup Designed Router）角色。

   R1的s2/0：（从图可知，s2/0连接的网络类型为`{{Lab5-p2-q9-1}}`，Cost=`{{Lab5-p2-q9-2}}`，邻居Router ID=`{{Lab5-p2-q9-3}}`）

   {{Lab5-p2-s9-r1_s20}}

   R1的f0/1：（f0/1连接的网络类型为`{{Lab5-p2-q9-4}}`，Cost=`{{Lab5-p2-q9-5}}`，邻居Router ID=`{{Lab5-p2-q9-6}}`，DR的Router ID是`{{Lab5-p2-q9-7}}`，接口IP是`{{Lab5-p2-q9-8}}`，BDR的Router ID是`{{Lab5-p2-q9-9}}`，接口IP是`{{Lab5-p2-q9-10}}`）
   
   {{Lab5-p2-s9-r1_f01}}
   
   R1的f0/0：（f0/1连接的网络类型为`{{Lab5-p2-q9-11}}`，Cost=`{{Lab5-p2-q9-12}}`，DR的Router ID是`{{Lab5-p2-q9-13}}`，接口IP是`{{Lab5-p2-q9-14}}`）
   
   {{Lab5-p2-s9-r1_f00}}
   
   
   
10. 查看R1、R2、R3的路由表，与RIP比较，OSPF所选择的路由有何不同，谁的优先级高？跟踪PC1到PC2的路由。

    R1路由表：（从图可知，对于PC2的网络，OSPF选择的下一跳IP地址是`{{Lab5-p2-q10-1}}`，由于OSPF的路由管理距离为110，比RIP的管理距离120优先级更高，所以把之前RIP选择的路由替换了）

    {{Lab5-p2-s10-r1_route_ospf}}

    R2路由表：（从图可知，对于PC1的网络，OSPF选择的下一跳IP地址是`{{Lab5-p2-q10-2}}`）

    {{Lab5-p2-s10-r2_route_ospf}}

    R3路由表：

    {{Lab5-p2-s10-r3_route_ospf}}

    PC1→PC2的路由跟踪：（经过的路由器顺序是R1、`{{Lab5-p2-q10-3}}`、`{{Lab5-p2-q10-4}}`）

    {{Lab5-p2-s10-pc1_to_pc2_ospf}}

    

11. 断开R1和R3的接口（在R1或R3上`shutdown`该接口），再次显示R1的路由表，标记到达PC2所在子网的下一跳。

    R1的路由表：

    {{Lab5-p2-s11-r1_route_after_shutdown}}

    

12. 保存R1配置后（在R1上输入命令：`write`）重启路由器（右键菜单`reload`），查看R1的Router ID是否发生变化，变成了`{{Lab5-p2-q12-1}}`，取自`{{Lab5-p2-q12-2}}`接口的IP地址。原因是由于接口f0/1断开了，故其上的IP地址也暂时不可用，OSPF于是选择了另一个可用IP地址作为Router ID，而原来的Router ID也未消失，看上去是来自另一台不存在的路由器。而R2配置了回环接口，OSPF会优先选择不会断开的回环接口的IP地址作为Router ID，就不会出现上述情况。

    R1的OSPF数据库：

    {{Lab5-p2-s12-r1_db_after_reload}}

    

13. 在R1上打开OSPF事件调试（命令：`debug ip ospf events`），然后重新连接R1和R3的接口（在R1或R3上`no shutdown`该接口），等与R3的邻居关系为Full后关闭debug，最后查看邻居关系。

    R1和R3重新建立邻接关系的事件记录：（从图可知，邻接关系建立经历了5个状态，分别是`{{Lab5-p2-q13-1}}`、`{{Lab5-p2-q13-2}}`、`{{Lab5-p2-q13-3}}`、`{{Lab5-p2-q13-4}}`、`{{Lab5-p2-q13-5}}`）

    {{Lab5-p2-s13-ospf_events}}

    R1的OSPF邻居详细信息：

    {{Lab5-p2-s13-r1_neighbor}}

    

14. 给R4、R6的回环接口、f0/0接口配置IP地址并激活，启用OSPF协议，接口均属于Area 0。过一会儿查看R4和R6的邻居信息（由于R2、R3、R4、R6在同一个广播网络中，四台路由器并不会都成为邻接关系，而是选出DR、BDR，然后各路由器与DR、BDR进行路由信息交换）。

    R4配置命令：
    
    ```
    {{Lab5-p2-s14-r4_config}}
    ```
    
    R6配置命令：
    
    ```
    {{Lab5-p2-s14-r6_config}}
    ```
    
    R4上查看邻居关系（与R6是邻居，但不建立邻接关系，重启后可能会变化）：
    
    {{Lab5-p2-s14-r4_neighbor}}
    
    R6上查看邻居关系（与R4是邻居，但不建立邻接关系，重启后可能会变化）：
    
    {{Lab5-p2-s14-r6_neighbor}}
    
    

### Part 3：配置多域OSPF

15. 给R4的f0/1接口、R5的回环接口、f0/1和f0/0接口配置IP地址、激活端口，并启用OSPF协议，各接口均属于Area 1。配置PC3的IP地址和默认路由。过一会儿，查看R2、R5上的路由表，标出区域间路由（IA），测试PC3与PC1的连通性。

    R4配置命令：

    ```kotlin
    {{Lab5-p3-s15-r4_area1}}
    ```
    
    R5配置命令：
    
    ```kotlin
    {{Lab5-p3-s15-r5_area1}}
    ```

    PC3配置命令：

    ```kotlin
    {{Lab5-p3-s15-pc3_config}}
    ```

    R2的路由表：目标为Area 1中的子网的下一跳IP地址均为`{{Lab5-p3-q15-1}}`，从`{{Lab5-p3-q15-2}}`接口发出。

    {{Lab5-p3-s15-r2_route_ia}}

    R5的路由表：目标为Area 0中的子网的下一跳IP地址均为`{{Lab5-p3-q15-3}}`，从`{{Lab5-p3-q15-4}}`接口发出。

    {{Lab5-p3-s15-r5_route_ia}}

    PC3→PC1的连通性：

    {{Lab5-p3-s15-pc3_to_pc1}}




16. 分别在R2、R4、R5上显示OSPF数据库信息，关注是否出现其他Area的信息。

    R2：没有Area 1的具体信息，但是该区域的子网地址`{{Lab5-p3-q16-1}}`、`{{Lab5-p3-q16-2}}`、`{{Lab5-p3-q16-3}}`由路由器`{{Lab5-p3-q16-4}}`汇聚后以区域间链路的形式进行通告。

    {{Lab5-p3-s16-r2_ospf_db}}

    R5：没有Area 的具体信息，但是该区域的子网地址全部由路由器`{{Lab5-p3-q16-5}}`汇聚后以区域间链路的形式进行通告。

    {{Lab5-p3-s16-r5_ospf_db}}

    R4：有Area 1和Area 0的具体信息，由于R4是区域边界路由器（ABR），所以对区域内的链路进行了汇聚，然后以区域间路由的形式向其他区域进行链路状态通告（LSA），其中：

    向Area 0通告的属于Area 1的链路有`{{Lab5-p3-q16-6}}`、`{{Lab5-p3-q16-7}}`、`{{Lab5-p3-q16-8}}`；

    向Area 1通告的属于Area 0的链路有`{{Lab5-p3-q16-9}}`、`{{Lab5-p3-q16-10}}`、`{{Lab5-p3-q16-11}}`、`{{Lab5-p3-q16-12}}`、`{{Lab5-p3-q16-13}}`、`{{Lab5-p3-q16-14}}`、`{{Lab5-p3-q16-15}}`、`{{Lab5-p3-q16-16}}`。

    {{Lab5-p3-s16-r4_ospf_db_abr}}

    

17. 分别在R1、R5上查看区域边界路由器（ABR）信息（命令：`show ip ospf border-routers`)

    R1：当前已知的区域0内的ABR的IP地址为`{{Lab5-p3-q17-1}}`，下一跳IP地址为`{{Lab5-p3-q17-2}}`。

    {{Lab5-p3-s17-r1_abr}}

    R5：当前已知的区域1内的ABR的IP地址为`{{Lab5-p3-q17-3}}`，下一跳IP地址为`{{Lab5-p3-q17-4}}`。

    {{Lab5-p3-s17-r5_abr}}

    

18. 给R6的f0/1、R8的各接口配置IP地址并激活，启用OSPF协议，各接口均属于Area 2。配置PC4的IP地址和默认路由。过一会，查看R8上的路由表，标出Area 1的区域间路由，测试PC4与PC1、PC3的连通性。

    R6配置命令：

    ```kotlin
    {{Lab5-p3-s18-r6_area2}}
    ```
    
    R8配置命令：
    
    ```kotlin
    {{Lab5-p3-s18-r8_area2}}
    ```

    R8的路由表：如图所示，区域间路由包含了Area 1和Area 0的地址，其中Area 1的子网地址有`{{Lab5-p3-q18-1}}`、`{{Lab5-p3-q18-2}}`、`{{Lab5-p3-q18-3}}`。
    
    {{Lab5-p3-s18-r8_route}}
    
    PC4→PC1的连通性：
    
    {{Lab5-p3-s18-pc4_to_pc1}}
    
    PC4→PC3的连通性：
    
    {{Lab5-p3-s18-pc4_to_pc3}}
    
    
    
19. 如果之前未配置Frame Relay数据链路，请在此时进行配置（参考GNS3指南）。

    FR交换机的虚链路配置表截图：

    {{Lab5-p3-s19-fr_switch_config}}

    

20. 给R5的s2/0接口配置封装协议为Frame Relay（命令：`encapsulation frame-relay`，由于GNS3自带的FR交换机只支持ANSI模式，而路由器默认的是Cisco，所以需再加一句`frame-relay lmi-type ANSI`)并激活，然后创建2个子接口，配置其IP地址、接口DLCI（命令：`frame-relay interface-dlci [dlci]`, dlci值等于Frame Relay交换机上定义的数据链路相关DLCI值），最后配置R5的s2/0接口属于Area 1。

    R5配置命令：

    ```kotlin
    {{Lab5-p3-s20-r5_fr_config}}
    ```
    
    
    
21. 给R7的各接口配置IP地址、激活，其中回环接口和f0/0接口属于Area 2，s2/0接口属于Area 1，配置s2/0封装协议为Frame Relay，DLCI值设为Frame Relay交换机上R5-R7之间数据链路的相关DLCI值。

    R7配置命令：

    ```kotlin
    {{Lab5-p3-s21-r7_fr_config}}
    ```
    
    在R7上查看Frame Relay映射（命令：`show frame-relay map`）：
    
    {{Lab5-p3-s21-r7_fr_map}}
    
    在R5上查看Frame Relay映射（命令：`show frame-relay map`）：
    
    {{Lab5-p3-s21-r5_fr_map}}
    
    在R7上测试到R5的连通性（由于R5-R7采用的是点对点Frame Relay连接，只有R5的1个子接口地址可以通）：
    
    {{Lab5-p3-s21-r7_ping_r5}}
    
    
    
22. 给R9的各接口配置IP地址、激活，其中回环接口和f0/1接口属于Area 3，s2/0接口属于Area 1，配置s2/0封装协议为Frame Relay，DLCI值设为Frame Relay交换机上R5-R9之间数据链路的相关DLCI值。

    R9配置命令：

    ```kotlin
    {{Lab5-p3-s22-r9_fr_config}}
    ```
    
    在R9上查看Frame Relay映射（命令：`show frame-relay map`）：
    
    {{Lab5-p3-s22-r9_fr_map}}
    
    在R9上测试到R5的连通性（由于R5-R9采用的是点对点Frame Relay连接，只有R5的1个子接口地址可以通。如果在R5上测试，需要加上参数`source s2/0`指定接口）：
    
    {{Lab5-p3-s22-r9_ping_r5}}
    
    在R9上测试到R7的连通性（R5、R7、R9通过帧中继交换机连接的形式称为非广播式多路访问，虽然路由器在同一个IP子网，但由于数据链路不是广播式的，所以在没有建立点对点数据链路的情况下，是不能通信的）：
    
    {{Lab5-p3-s22-r9_ping_r7}}
    
    
    
23. 分别在R5、R7、R9上查看OSPF邻居关系（此时OSPF认为当前链路属于广播式，需要先竞选出DR，而实际网络为非广播式的，因此三者之间的邻居关系暂时不能建立）

    在R5上查看邻居关系:

    {{Lab5-p3-s23-r5_neighbor_before}}

    在R7上查看邻居关系:

    {{Lab5-p3-s23-r7_neighbor_before}}

    在R9上查看邻居关系:

    {{Lab5-p3-s23-r9_neighbor_before}}

    

24. 分别在R5、R7、R9上配置s2/0的接口为点对多点的网络类型（命令：`ip ospf network point-to-multipoint`），然后再次查看邻居关系：

    R5配置命令：

    ```kotlin
    {{Lab5-p3-s24-r5_p2mp}}
    ```
    
    R7配置命令：
    
    ```kotlin
    {{Lab5-p3-s24-r7_p2mp}}
    ```
    
    R9配置命令：
    
    ```kotlin
    {{Lab5-p3-s24-r9_p2mp}}
    ```

    在R5上查看邻居关系:
    
    {{Lab5-p3-s24-r5_neighbor_after}}
    
    在R7上查看邻居关系:
    
    {{Lab5-p3-s24-r7_neighbor_after}}
    
    在R9上查看邻居关系:
    
    {{Lab5-p3-s24-r9_neighbor_after}}
    
    
    
25. 分别在R5、R8、R7上查看OSPF数据库（命令：`show ip ospf database`），观察Summary Net Link部分，你发现了什么现象？

    R5的OSPF数据库：观察得知，Area 1所有的的聚合路由都是由区域边界路由器(ABR)`{{Lab5-p3-q25-1}}`宣告的，而R7作为Area 1和Area 2的ABR，却没有向Area 1宣告Area 2的路由信息，是因为所有的Area都只和Area 0进行路由信息交换。

    {{Lab5-p3-s25-r5_ospf_db_summary}}

    R8的OSPF数据库：观察得知，Area 2所有的的聚合路由都是由区域边界路由器(ABR)`{{Lab5-p3-q25-2}}`宣告的，而R7作为Area 1和Area 2的ABR，也没有向Area 2宣告Area 1的路由信息。

    {{Lab5-p3-s25-r8_ospf_db_summary}}

    R7的OSPF数据库：观察得知，Area 1所有的的聚合路由都是由区域边界路由器(ABR)`{{Lab5-p3-q25-3}}`宣告的，Area 2所有的的聚合路由都是由区域边界路由器(ABR)`{{Lab5-p3-q25-4}}`宣告的。

    {{Lab5-p3-s25-r7_ospf_db_summary}}

    

26. 在R8上查看去往PC3所在网络的路由信息（命令：`show ip route [ip network]`）

    R8的路由信息：观察得知，前往子网`{{Lab5-p3-q26-1}}`的下一跳IP地址是`{{Lab5-p3-q26-2}}`，是路由器`{{Lab5-p3-q26-3}}`。

    {{Lab5-p3-s26-r8_route_to_pc3}}

    

27. 断开路由器R6的f0/0接口（命令：`shutdown`），等候片刻，在R8上再次查看路由信息：

    R8的路由信息：观察得知，前往子网`{{Lab5-p3-q27-1}}`的路由已经不存在。

    {{Lab5-p3-s27-r8_route_after_shutdown}}

    看看R7有没有PC3的路由信息：观察得知，前往子网`{{Lab5-p3-q27-2}}`的路由是存在的，但是由于Area 2和Area 1不直接交换路由信息，R7没有向Area 2宣告路由的存在。

    {{Lab5-p3-s27-r7_route_pc3}}

    重新打开R6的f0/0接口，稍候再次查看R8的路由信息是否恢复。

    

    

28. 给R10的f0/0、f0/1接口配置IP地址并激活，启用OSPF协议，各接口均属于Area 3。配置PC5的IP地址和默认路由。过一会，查看R10上的路由表和OSPF数据库。

    R10配置命令：

    ```kotlin
    {{Lab5-p3-s28-r10_config}}
    ```
    
    R10的OSPF数据库：观察可知，数据库中没有其他Area的信息，因为Area 3和Area 1不直接交换信息
    
    {{Lab5-p3-s28-r10_ospf_db}}
    
    R10的路由表：观察可知，路由表中没有其他Area的信息，因为OSPF数据库中缺乏相关数据。
    
    {{Lab5-p3-s28-r10_route}}
    
    
    
29. 在Area 1上的两个边界路由器R9、R4之间为Area 3和Area 0创建虚链路（命令：`area [area-id] virtual-link RID`），这样Area 3就能和Area 0进行路由信息交换了。其中，area-id写1，RID写对方的Router ID，稍候查看虚链路建立情况（命令：`show ip ospf virtual-links`）和邻居信息（命令：`show ip ospf neighbor`）。

    R4配置命令：

    ```kotlin
    {{Lab5-p3-s29-r4_vlink}}
    ```
    

    R9配置命令：

    ```kotlin
    {{Lab5-p3-s29-r9_vlink}}
    ```

    查看R4虚链路：观察得知，R4通过区域`{{Lab5-p3-q29-1}}`的接口`{{Lab5-p3-q29-2}}`与R9（RID是`{{Lab5-p3-q29-3}}`）建立了虚链路，使用的Cost值为`{{Lab5-p3-q29-4}}`。
    
    {{Lab5-p3-s29-r4_vlink_show}}
    
    查看R9虚链路：观察得知，R9通过区域`{{Lab5-p3-q29-5}}`的接口`{{Lab5-p3-q29-6}}`与R4（RID是`{{Lab5-p3-q29-7}}`）建立了虚链路，使用的Cost值为`{{Lab5-p3-q29-8}}`。
    
    {{Lab5-p3-s29-r9_vlink_show}}
    
    查看R4邻居信息：观察得知，R4通过接口`{{Lab5-p3-q29-9}}`与R9（RID是`{{Lab5-p3-q29-10}}`）建立了邻接关系。
    
    {{Lab5-p3-s29-r4_neighbor_vlink}}
    
    查看R9邻居信息：观察得知，R9通过接口`{{Lab5-p3-q29-11}}`与R4（RID是`{{Lab5-p3-q29-12}}`）建立了邻接关系。
    
    {{Lab5-p3-s29-r9_neighbor_vlink}}




30. 再次显示R10的路由表和OSPF数据库，标出PC1、PC2、PC3所在的子网相关记录。

    R10的路由表：

    {{Lab5-p3-s30-r10_route_after_vlink}}

    R10的OSPF数据库：观察得知，所有其他区域路由信息均由区域边界路由器`{{Lab5-p3-q30-1}}`宣告。

    {{Lab5-p3-s30-r10_db_after_vlink}}

    

31. 在R9上手工合并Area 0上的子网路由（命令：`area 0 range [ip_net] [mask]`，其中`ip_net`写成10.0.0.0，mask写成255.255.0.0，表示10.0.x.x这些网络都在area 0上），然后显示R9和R10的路由表，看看所指定的子网是否合并了路由

    R9的路由表：标出合并的那条路由，这条路由采用了特殊的接口`{{Lab5-p3-q31-1}}`作为下一跳。

    {{Lab5-p3-s31-r9_route_summary}}

    R10的路由表：标出合并的那条路由，这条路由下一跳的IP地址是`{{Lab5-p3-q31-2}}`，是路由器`{{Lab5-p3-q31-3}}`的接口。

    {{Lab5-p3-s31-r10_route_summary}}

    

32. 整理各路由器的当前运行配置，选择与本实验相关的内容记录在文本文件中，每个设备一个文件，分别命名为R1.txt、R2.txt等，随实验报告一起打包上传。



## 六、实验结果与分析

根据你观察到的实验数据和对实验原理的理解，分别解答以下问题：

- 在一个网络中各路由器的OSPF进程号是否一定要相同？一个路由器上可以配置多个进程号吗？

  {{Lab5-q1}}

-   未手工指定Router ID时，如果没有给回环接口配置IP地址，会从哪一个接口选取地址作为Router ID？如果给回环接口配置了IP地址，又会从哪一个接口选取地址作为Router ID？
    
    {{Lab5-q2}}
    
-   如果Router ID对应的接口down了，路由器会自动重新选择另一个接口地址作为新的Router ID吗？
    
    {{Lab5-q3}}

- 宣告网络属于哪个area的命令中，网络地址后面的参数是子网掩码吗？为什么要写成0.0.255.255，而不是255.255.0.0？

  {{Lab5-q4}}

-   是不是所有其他Area上的路由器都只和Area 0上的路由器进行路由信息交换？虚链路的作用是什么？
    
    {{Lab5-q5}}
    
- 为什么要在区域边界路由器上进行路由合并？

  {{Lab5-q6}}



## 七、讨论、心得

在完成本实验后，你可能会有很多待解答的问题，你可以把它们记在这里，接下来的学习中，你也许会逐渐得到答案的，同时也可以让老师了解到你有哪些困惑，老师在课堂可以安排针对性地解惑。等到课程结束后，你再回头看看这些问题时你或许会有不同的见解：

{{lab5-question}}

在实验过程中你可能会遇到的困难，并得到了宝贵的经验教训，请把它们记录下来，提供给其他人参考吧：

{{lab5-experience}}

你对本实验安排有哪些更好的建议呢？欢迎献计献策：

{{lab5-suggestion}}
