<img src="Lab3/cover.jpg" alt="cover" style="zoom:43%;" />

<left>
  <font face="楷体" size = 5>
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp课程名称：</font><font face="楷体" size = 5><u>&nbsp&nbsp&nbsp计算机网络&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp实验名称：<u>&nbsp&nbsp&nbsp使用三层交换机组网&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp姓&nbsp&nbsp&nbsp&nbsp名：</font><font face="楷体" size = 5><u>&nbsp&nbsp&nbsp 姓名&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp学&nbsp&nbsp&nbsp&nbsp院：</font><font face="楷体" size = 5><u>&nbsp&nbsp&nbsp计算机科学与技术学院&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
     &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp系：</font><font face="楷体" size = 5><u>&nbsp&nbsp&nbsp计算机科学与技术系&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
     &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp专&nbsp&nbsp&nbsp&nbsp业：<u>&nbsp&nbsp&nbsp计算机科学与技术&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp学&nbsp&nbsp&nbsp&nbsp号：<u>&nbsp&nbsp&nbsp学号&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
     &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp指导教师：<u>&nbsp&nbsp&nbsp陆系群&nbsp&nbsp&nbsp</u>
  </font><br/><br/><br/>
    <center><font face="黑体" size = 5>
    报告日期: 2025年月日
  </font>
</left>
<div STYLE="page-break-after: always;"></div>

<center>
    <font face="黑体" size=5>
        <b>浙江大学实验报告</b>
    </font><br/><br/><br/></center>
<left>  
    <font face="黑体" size=4>
         &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp课程名称：<u>&nbsp&nbsp&nbsp&nbsp计算机网络&nbsp&nbsp&nbsp</u>实验类型:<u>&nbsp&nbsp&nbsp&nbsp综合&nbsp&nbsp&nbsp</u>
        </font><br/><br/>
    <font face="黑体" size=4>
         &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp实验项目名称:<u>&nbsp&nbsp&nbsp&nbsp Lab3:使用三层交换机组网
 &nbsp&nbsp&nbsp</u>
        </font><br/><br/><font face="黑体" size=4>
         &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp学生姓名:<u>&nbsp&nbsp  &nbsp</u>专业: <u>&nbsp&nbsp 计算机科学与技术&nbsp&nbsp</u>学号: <u>&nbsp&nbsp &nbsp&nbsp</u>
        </font><br/><br/><font face="黑体" size=4>
         &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp同组学生姓名:<u>&nbsp&nbsp&nbsp&nbsp  &nbsp&nbsp&nbsp</u>指导老师: <u>&nbsp&nbsp&nbsp&nbsp陆系群&nbsp&nbsp&nbsp&nbsp</u>
        </font><br/><br/><font face="黑体" size=4>
         &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp实验地点:<u>&nbsp&nbsp&nbsp曹光彪西-304 &nbsp&nbsp&nbsp</u>实验日期: <u>&nbsp&nbsp 2025年月日&nbsp&nbsp</u>
    </font><br/></left>



## 一、实验目的

1.  掌握并比较两种VLAN间数据交换的方法。

2.  学习如何配置子接口；

3.  学习掌握三层交换机的工作原理；

4.  学习如何配置三层交换机；



## 二、实验内容

由于二层交换机不转发不同VLAN间的数据，所以有2种方式让不同VLAN的PC能够相互通信。第一种方式称为单臂路由器，是利用路由器的子接口功能，将路由器的物理接口逻辑上分为多个子接口，每个子接口属于不同的VLAN，能够接收到不同的VLAN数据，然后在路由器内部通过第三层进行数据交换，实现VLAN间通信。第二种方式是采用三层交换机，是将二层交换机的功能加入了三层路由功能的做法。实验分为两部分，将分别按照两种方式进行。



## 三、主要仪器设备

PC机、路由器、Console连接线、直联网络线、交叉网络线

> [!NOTE]
>
> 本实验可使用模拟器，如使用模拟器完成实验，需独立完成实验全部步骤



## 四、操作方法与实验步骤

### Part 1. 单臂路由

-   将2台PC（PC1、PC2）和一台路由器都连接到一台二层交换机；

-   在交换机上增加1个VLAN，并使得2台PC所连端口分别属于2个VLAN。给2个PC配置不同子网的IP地址；

-   将二层交换机和路由器连接的端口配置成VLAN Trunk模式；

-   在路由器连接交换机的端口上创建2个子接口，并配置子接口所属的VLAN，分别给2个子接口配置IP地址，并激活端口；

-   将2台PC的默认网关分别设置为路由器的2个子接口的IP地址；

-   测试2台PC能否互相Ping通。



### Part 2. 三层交换

-   将第一部分的路由器删除后，将二层交换机和一台三层交换机连接，并新增2台PC（PC3、PC4）直接连接到三层交换机；

-   在三层交换机上增加1个VLAN，并使得PC3、PC4所连端口分别属于2个VLAN。给这2个VLAN接口配置IP地址，并启用路由功能；

-   给PC3、PC4配置所在VLAN内的合适IP地址，并将2台PC的默认网关分别设置为三层交换机2个VLAN接口的IP地址；

-   测试PC3、PC4能否互相Ping通。

-   测试不同交换机上的PC间（如PC1、PC3）能否互相Ping通。



## 五、实验数据记录和处理

> [!NOTE]
>
> 以下实验记录均需结合屏幕截图，进行文字标注和描述，图片应大小合适、关键部分清晰可见，可直接在图片上进行标注，也可以单独用文本进行描述。

### Part 1 单臂路由

1. 将2台PC和一台路由器都连接到一台二层交换机，在交换机上增加1个VLAN，并使得2台PC所连端口分别属于2个VLAN。给2个PC分配不同子网的IP地址。

   拓扑图：

   {{image:Lab3-p1-s1-topology}}

2. 验证两个PC之间能否Ping通（不同的VLAN之间不通）

   结果截图：

   {{image:Lab3-p1-s2-ping_test}}

   

3. 将二层交换机和路由器连接的端口配置成VLAN Trunk模式。

   

4. 连接路由器的Console口，进入路由器的配置模式。在路由器连接交换机的端口上创建2个子接口（命令：`interface [type] [slot/unit.sub]`，如：`interface e0/1.1`），并配置子接口所属的VLAN（命令：`encapsulation dot1q VLAN编号`），然后使用与2台PC一致的子网，分别给2个子接口配置IP地址，最后激活端口（命令：`no shutdown`）

   输入的命令：

   ```
   {{Lab3-p1-s4-router_config}}
   ```

   

5. 按照前述拓扑图，给PC配置IP地址，并将默认路由器地址（gateway）按照所属VLAN，分别设置为路由器的2个子接口的IP地址。

   配置截图：

   {{image:Lab3-p1-s5-pc1_config}}

   {{image:Lab3-p1-s5-pc2_config}}

   

6. 测试2台PC能否Ping通各自的路由器子接口地址

   结果截图：

   {{image:Lab3-p1-s6-pc1_ping_router}}

   {{image:Lab3-p1-s6-pc2_ping_router}}

   

7. 测试2台PC能否互相Ping通

   结果截图：

   {{image:Lab3-p1-s7-pc_ping_test}}

   

8.  记录路由器的路由表内容（命令：`show ip route`）

    结果截图：

    {{image:Lab3-p1-s8-routing_table}}

    

9.  记录路由器上的运行配置（命令：`show running-config`)，复制粘贴本节相关的文本（完整的内容请放在文件中，命名为R1.txt）。

    本节相关的运行配置：

    ```
    {{Lab3-p1-s9-running_config}}
    ```

    

### Part 2 三层交换

1. 将第一部分的路由器移除后，将二层交换机和一台三层交换机连接（使用GNS3模拟时，请参见指南中“十五、使用路由器模拟三层交换机”的具体步骤，创建一个三层交换机设备），并新增2台PC（PC3、PC4）直接连接到三层交换机，为PC3、PC4分配所在VLAN内的合适IP地址，并在图中标记各设备的IP地址和VLAN

   拓扑图：

   {{image:Lab3-p2-s1-l3_topology}}

   

2. 在三层交换机上增加1个VLAN，并使得2台PC所连端口分别属于2个VLAN。

   输入的命令：

   ```
   {{Lab3-p2-s2-vlan_config_cmd}}
   ```

   配置结果截图：

   {{image:Lab3-p2-s2-vlan_show_result}}

   

3. 给2个VLAN接口配置IP地址（命令：interface vlan VLAN编号，ip address IP地址）

   输入的命令：

   ```
   {{Lab3-p2-s3-vlan_ip_config}}
   ```

   

4. 在三层交换机上启用路由功能（命令：ip routing）（在GNS3上用路由器模拟三层交换机时，此步骤不需要）

5. 按照前述拓扑图，给PC3、PC4配置IP地址，并将PC3、PC4的默认路由器分别设置为三层交换机2个VLAN接口的IP地址。

   配置截图：

   {{image:Lab3-p2-s5-}}

   {{image:Lab3-p2-s5-}}

   

6. 测试PC3、PC4能否Ping通各自的VLAN接口地址

   结果截图：

   {{image:Lab3-p2-s6-pc3_config}}

   {{image:Lab3-p2-s6-pc4_config}}



7. 测试PC3、PC4能否互相Ping通。

   结果截图：

   {{image:Lab3-p2-s7-pc34_ping_test}}

   

8. 测试不同交换机上属于不同VLAN的PC间的连通性（如PC1-\>PC4, PC2-\>PC3）

   结果截图：

   * PC1→PC4

     {{image:Lab3-p2-s8-pc1_to_pc4}}

   * PC2→PC3

     {{image:Lab3-p2-s8-pc2_to_pc3}}



9. 如果有些PC之间是不能Ping通的，思考一下是什么原因造成的。接下来在三层交换机上把与二层交换机互联的端口设置成Trunk模式。

   输入的命令：

   ```
   {{Lab3-p2-s9-trunk_config_cmd}}
   ```

   

10. 再次测试之前不通的PC间的连通性。

    结果截图：

    * PC2→PC3

      {{image:Lab3-p2-s10-pc2_to_pc3_after}}

      

11. 显示三层交换机上的路由信息

    结果截图：

    {{image:Lab3-p2-s11-l3_routing_info}}

    

12. 记录三层交换机上的当前运行配置, 复制粘贴本节相关的文本（完整的内容请放在文件中，命名为S2.txt）。

    本节相关的运行配置：

    ```
    {{Lab3-p2-s12-l3_running_config}}
    ```

    

## 六、实验结果与分析

根据你观察到的实验数据和对实验原理的理解，分别解答以下问题：

1. 为什么路由器的端口可以配置IP地址，而三层交换机的端口跟二层交换机一样不能配置IP地址？

   {{Lab3-q1}}

2. 本实验中为什么要用子接口？有什么好处？使用物理接口可以吗？

   {{Lab3-q2}}

3. 直连三层交换机的PC的默认路由器地址应该设为什么？

   {{Lab3-q3}}

4. 三层交换机和二层交换机互联时，连在二层交换机上VLAN2的PC为什么Ping不通连在三层交换机上VLAN 1的PC？

   {{Lab3-q4}}

5. Ping测试时，为什么一开始有几次不通，后面又通了？

   {{Lab3-q5}}

6. 既然路由器可以实现VLAN间数据交换，为何还要设计三层交换机呢？

   {{Lab3-q6}}

## 七、讨论、心得

在完成本实验后，你可能会有很多待解答的问题，你可以把它们记在这里，接下来的学习中，你也许会逐渐得到答案的，同时也可以让老师了解到你有哪些困惑，老师在课堂可以安排针对性地解惑。等到课程结束后，你再回头看看这些问题时你或许会有不同的见解：





在实验过程中你可能会遇到的困难，并得到了宝贵的经验教训，请把它们记录下来，提供给其他人参考吧：





你对本实验安排有哪些更好的建议呢？欢迎献计献策：
