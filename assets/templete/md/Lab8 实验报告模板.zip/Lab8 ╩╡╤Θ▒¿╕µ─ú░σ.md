<img src="Lab8/cover.jpg" alt="cover" style="zoom:43%;" />

<div align="left">
  <font face="楷体" size = 5>
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp课程名称：</font><font face="楷体" size = 5><u>&nbsp&nbsp&nbsp计算机网络&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp实验名称：<u>&nbsp&nbsp&nbsp实现一个轻量级的WEB服务器&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp姓&nbsp&nbsp&nbsp&nbsp名：</font><font face="楷体" size = 5><u>&nbsp&nbsp&nbsp 姓名&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp学&nbsp&nbsp&nbsp&nbsp院：</font><font face="楷体" size = 5><u>&nbsp&nbsp&nbsp计算机科学与技术学院&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
     &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp系：</font><font face="楷体" size = 5><u>&nbsp&nbsp&nbsp计算机科学与技术系&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
     &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp专&nbsp&nbsp&nbsp&nbsp业：<u>&nbsp&nbsp&nbsp计算机科学与技术&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
      &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp学&nbsp&nbsp&nbsp&nbsp号：<u>&nbsp&nbsp&nbsp学号&nbsp&nbsp&nbsp</u>
  </font><br/><br/>
    <font face="楷体" size = 5>
     &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp指导教师：<u>&nbsp&nbsp&nbsp陆系群&nbsp&nbsp&nbsp</u>
  </font><br/><br/><br/>
    <center><font face="黑体" size = 5>
    报告日期: 2025年月日
  </font>
</center>
</div>
<div STYLE="page-break-after: always;"></div>

<center>
    <font face="黑体" size=5>
        <b>浙江大学实验报告</b>
    </font><br/><br/><br/></center>
<div align="left"> 
    <font face="黑体" size=4>
         &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp课程名称：<u>&nbsp&nbsp&nbsp&nbsp计算机网络&nbsp&nbsp&nbsp</u>实验类型:<u>&nbsp&nbsp&nbsp&nbsp综合&nbsp&nbsp&nbsp</u>
        </font><br/><br/>
    <font face="黑体" size=4>
         &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp实验项目名称:<u>&nbsp&nbsp&nbsp&nbsp Lab8:实现一个轻量级的WEB服务器
 &nbsp&nbsp&nbsp</u>
        </font><br/><br/><font face="黑体" size=4>
         &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp学生姓名:<u>&nbsp&nbsp  &nbsp</u>专业: <u>&nbsp&nbsp 计算机科学与技术&nbsp&nbsp</u>学号: <u>&nbsp&nbsp &nbsp&nbsp</u>
        </font><br/><br/><font face="黑体" size=4>
         &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp同组学生姓名:<u>&nbsp&nbsp&nbsp&nbsp  &nbsp&nbsp&nbsp</u>指导老师: <u>&nbsp&nbsp&nbsp&nbsp陆系群&nbsp&nbsp&nbsp&nbsp</u>
        </font><br/><br/><font face="黑体" size=4>
         &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp实验地点:<u>&nbsp&nbsp&nbsp曹光彪西-304 &nbsp&nbsp&nbsp</u>实验日期: <u>&nbsp&nbsp 2025年月日&nbsp&nbsp</u>
    </font><br/></div>





## 一、实验目的

深入掌握HTTP协议规范，学习如何编写标准的互联网应用服务器。



## 二、实验内容

-   服务程序能够正确解析HTTP协议，并传回所需的网页文件和图片文件

-   使用标准的浏览器，如Chrome或者Safari，输入服务程序的URL后，能够正常显示服务器上的网页文件和图片

-   服务端程序界面不做要求，使用命令行或最简单的窗体即可

-   功能要求如下：

1.  服务程序运行后监听在80端口或者指定端口

2.  接受浏览器的TCP连接（支持多个浏览器同时连接）

3.  读取浏览器发送的数据，解析HTTP请求头部，找到感兴趣的部分

4.  根据HTTP头部请求的文件路径，打开并读取服务器磁盘上的文件，以HTTP响应格式传回浏览器。要求按照文本、图片文件传送不同的`Content-Type`，以便让浏览器能够正常显示。

5.  分别使用单个纯文本、只包含文字的HTML文件、包含文字和图片的HTML文件进行测试，浏览器均能正常显示。

-   本实验可以在前一个Socket编程实验的基础上继续，也可以使用第三方封装好的TCP类进行网络数据的收发

-   本实验要求不使用任何封装HTTP接口的类库或组件，也不使用任何服务端脚本程序如JSP、ASPX、PHP等



## 三、主要仪器设备

联网的PC机、Wireshark软件、Visual Studio Code、gcc或Java集成开发环境。



## 四、操作方法与实验步骤

-   阅读HTTP协议相关标准文档，详细了解HTTP协议标准的细节，有必要的话使用Wireshark抓包，研究浏览器和WEB服务器之间的交互过程

-   创建一个文档目录，与服务器程序运行路径分开

-   准备一个纯文本文件，命名为`test.txt`，存放在`txt`子目录下面

-   准备好一个图片文件，命名为`logo.jpg`，放在`img`子目录下面

- 写一个HTML文件，命名为`test.html`，放在`html`子目录下面，主要内容为：

  ```html
  <html>
      <head><title>Test</title></head>
      <body>
          <h1>This is a test<h1>
          <img src="img/logo.jpg">
          <form action="dopost" method="POST">
              Login:<input name="login">
              Pass:<input name="pass">
              <input type="submit" value="login">
          </form>
      </body>
  </html>
  ```

-   将`test.html`复制为`noimg.html`，并删除其中包含`img`的这一行。

-   服务端编写步骤（**需要采用多线程模式**）

a)  运行初始化，打开Socket，监听在指定端口（**请使用学号的后4位作为服务器的监听端口**）

b)  主线程是一个循环，主要做的工作是等待客户端连接，如果有客户端连接成功，为该客户端创建处理子线程。该子线程的主要处理步骤是：

1.  不断读取客户端发送过来的字节，并检查其中是否连续出现了2个回车换行符，如果未出现，继续接收；如果出现，按照HTTP格式解析第1行，分离出方法、文件和路径名，其他头部字段根据需要读取。

-   **如果解析出来的方法是GET**

2.  根据解析出来的文件和路径名，读取响应的磁盘文件（该路径和服务器程序可能不在同一个目录下，需要转换成绝对路径）。如果文件不存在，第3步的响应消息的状态设置为404，并且跳过第5步。

3.  准备好一个足够大的缓冲区，按照HTTP响应消息的格式先填入第1行（状态码=200），加上回车换行符。然后模仿Wireshark抓取的HTTP消息，填入必要的几行头部（需要哪些头部，请试验），其中不能缺少的2个头部是`Content-Type`和`Content-Length`。`Content-Type`的值要和文件类型相匹配（请通过抓包确定应该填什么），`Content-Length`的值填写文件的字节大小。

4.  在头部行填完后，再填入2个回车换行

5.  将文件内容按顺序填入到缓冲区后面部分。

-   **如果解析出来的方法是POST**

6. 检查解析出来的文件和路径名，如果不是`dopost`，则设置响应消息的状态为404，然后跳到第9步。如果是`dopost`，则设置响应消息的状态为200，并继续下一步。

7. 读取2个回车换行后面的体部内容（长度根据头部的`Content-Length`字段的指示），并提取出登录名`login`和密码`pass`的值。如果登录名是你的学号，密码是学号的后4位，则将响应消息设置为登录成功，否则将响应消息设置为登录失败。

8. 将响应消息封装成html格式，如

   ```
   <html><body>响应消息内容<body><html>
   ```

9.  准备好一个足够大的缓冲区，按照HTTP响应消息的格式先填入第1行（根据前面的情况设置好状态码），加上回车换行符。然后填入必要的几行头部，其中不能缺少的2个头部是`Content-Type`和`Content-Length`。`Content-Type`的值设置为`text/html`，如果状态码=200，则`Content-Length`的值填写响应消息的字节大小，并将响应消息填入缓冲区的后面部分，否则填写为0。

10. 最后一次性将缓冲区内的字节发送给客户端。

11. 发送完毕后，关闭socket，退出子线程。

c)  主线程还负责检测退出指令（如用户按退出键或者收到退出信号），检测到后即通知并等待各子线程退出。最后关闭Socket，主程序退出。

-   编程结束后，将服务器部署在一台机器上（本机也可以）。在服务器上分别放置纯文本文件`.txt`、只包含文字的测试HTML文件（将测试HTML文件中的包含`img`那一行去掉）、包含文字和图片的测试HTML文件（以及图片文件）各一个。

-   确定好各个文件的URL地址，然后使用浏览器访问这些URL地址，如http://x.x.x.x:port/dir/a.html，其中`port`是服务器的监听端口，`dir`是提供给外部访问的路径，请设置为与文件实际存放路径不同，通过服务器内部映射转换。

-   检查浏览器是否正常显示页面，如果有问题，查找原因，并修改，直至满足要求

-   使用多个浏览器同时访问这些URL地址，检查并发性



## 五、实验数据记录和处理

>  [!NOTE]
>
> 以下实验记录均需结合屏幕截图（截取源代码或运行结果），进行文字标注和描述。
>
> 请将以下内容和本实验报告一起打包成一个压缩文件上传：
>
> -   源代码：需要说明编译环境和编译方法，如果不能编译成功，将影响评分
>
> -   可执行文件：可运行的.exe文件或Linux可执行文件

- 服务器的主线程循环关键代码截图（解释总体处理逻辑，省略细节部分）

  

- 服务器的客户端处理子线程关键代码截图（解释总体处理逻辑，省略细节部分）

  

- 服务器运行后，用`netstat –an`显示服务器的监听端口

  

- 浏览器访问纯文本文件`.txt`时，浏览器的URL地址和显示内容截图。

  服务器上文件实际存放的路径：

  

  服务器的相关代码片段：

  

  Wireshark抓取的数据包截图（通过跟踪TCP流，只截取HTTP协议部分）：

  

- 浏览器访问只包含文本的HTML文件时，浏览器的URL地址和显示内容截图。

  服务器文件实际存放的路径：

  

  Wireshark抓取的数据包截图（只截取HTTP协议部分，包括HTML内容）：

  

- 浏览器访问包含文本、图片的HTML文件时，浏览器的URL地址和显示内容截图。

  服务器上文件实际存放的路径：

  

  Wireshark抓取的数据包截图（只截取HTTP协议部分，包括HTML、图片文件的部分内容）：

  

- 浏览器输入正确的登录名或密码，点击登录按钮（login）后的显示截图。

  服务器相关处理代码片段：

  

  Wireshark抓取的数据包截图（HTTP协议部分）

  

- 浏览器输入错误的登录名或密码，点击登录按钮（login）后的显示截图。

  

- Wireshark抓取的数据包截图（HTTP协议部分）

  

- 多个浏览器同时访问包含图片的HTML文件时，浏览器的显示内容截图（将浏览器窗口缩小并列）

  

- 多个浏览器同时访问包含图片的HTML文件时，使用`netstat –an`显示服务器的TCP连接（截取与服务器监听端口相关的）

  

## 六、实验结果与分析

根据你编写的程序运行效果，分别解答以下问题：

- HTTP协议是怎样对头部和体部进行分隔的？

  

- 浏览器是根据文件的扩展名还是根据头部的哪个字段判断文件类型的？

  

- HTTP协议的头部是不是一定是文本格式？体部呢？

  

- POST方法传递的数据是放在头部还是体部？两个字段是用什么符号连接起来的？

  



## 七、讨论、心得

实验过程中遇到的困难，得到的经验教训，对本实验安排的更好建议

